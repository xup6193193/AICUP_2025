#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import numpy as np
import os
from scipy.signal import detrend
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, RidgeClassifierCV
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.calibration import CalibratedClassifierCV # Import for Ridge probabilities
import time
from tqdm import tqdm
import warnings
import itertools

# --- MultiRocket Transformer Import Logic ---
try:
    from aeon.transformations.collection.convolution_based import MultiRocket as MultiRocketTransformer
    MULTIROCKET_SOURCE = "aeon"
except ModuleNotFoundError:
    try:
        # This is a hypothetical path for sktime, adjust if a stable version exists
        from sktime.transformations.panel.rocket import MultiRocket as MultiRocketTransformer
        MULTIROCKET_SOURCE = "sktime.transformations.panel.rocket"
    except ModuleNotFoundError:
        MultiRocketTransformer = None
        MULTIROCKET_SOURCE = 'Unavailable' # Set to a string to avoid None issues
print(f"Initializing with Transformer from: {MULTIROCKET_SOURCE if MultiRocketTransformer else 'Unavailable'}")
# --- End MultiRocket Import ---

# MODIFIED for 3-axis data (Ay, AccelMag, GyroMag)
def load_and_preprocess_series(file_path, fs=85.0, min_len_seconds=0.5, apply_instance_norm=False):
    """
    從文本文件中加載和預處理多變量時間序列。
    讀取6軸原始數據，但只輸出指定的3個特徵軸。
    """
    try:
        df = pd.read_csv(file_path, header=None, sep=r'\s+', engine='python')
        # 檢查欄位數是否至少為 6
        if df.shape[1] < 6: return None
        
        # 仍然需要讀取全部6軸原始數據來進行計算
        y_raw_6_axis = df.values
        
    except Exception: return None

    # --- 特徵工程：計算與組合指定的3軸 ---
    # 假設欄位順序為 Ax, Ay, Az, Gx, Gy, Gz (索引 0-5)
    ax, ay, az = y_raw_6_axis[:, 0], y_raw_6_axis[:, 1], y_raw_6_axis[:, 2]
    gx, gy, gz = y_raw_6_axis[:, 3], y_raw_6_axis[:, 4], y_raw_6_axis[:, 5]

    # 特徵1: Ay (原始數據)
    # ay 已經被提取

    # 特徵2: 計算合加速度向量大小
    acc_magnitude = np.sqrt(ax**2 + ay**2 + az**2)

    # 特徵3: 計算合旋轉速度大小
    gyro_magnitude = np.sqrt(gx**2 + gy**2 + gz**2)

    # 將指定的3個軸組合成一個 (n_timepoints, 3) 的陣列
    y_raw_3_axis = np.stack((ay, acc_magnitude, gyro_magnitude), axis=1)
    # --- 特徵工程結束 ---

    # 檢查時間序列長度
    if y_raw_3_axis.shape[0] < fs * min_len_seconds: return None

    # 對每一個軸 (現在是3個軸) 獨立進行 detrend 和 instance norm
    y_processed_3_axis = np.zeros_like(y_raw_3_axis, dtype=np.float32)
    for i in range(y_processed_3_axis.shape[1]): # 這個迴圈現在會自動遍歷 3 個軸
        y_channel = y_raw_3_axis[:, i]
        y_channel_detrended = detrend(y_channel, type='linear')
        
        if apply_instance_norm:
            std_dev = np.std(y_channel_detrended)
            if std_dev > 1e-7:
                y_channel_processed = (y_channel_detrended - np.mean(y_channel_detrended)) / std_dev
            else:
                y_channel_processed = y_channel_detrended
        else:
            y_channel_processed = y_channel_detrended
        
        y_processed_3_axis[:, i] = y_channel_processed

    # 回傳一個 (時間點數量, 3) 的 NumPy 陣列
    return y_processed_3_axis

# MODIFIED for 2D NumPy arrays
def adjust_series_length(series_list, fixed_length):
    """
    Adjusts the length of each 2D NumPy array in a list to a fixed length by padding or truncating.
    """
    adjusted_list = []
    if not series_list: return adjusted_list
    
    # Get the number of variables from the first sample (will be 3)
    n_variables = series_list[0].shape[1] 

    for s in series_list:
        current_len = s.shape[0]
        if current_len < fixed_length:
            # Create a padding array of zeros
            padding = np.zeros((fixed_length - current_len, n_variables), dtype=s.dtype)
            s_adjusted = np.vstack([s, padding])
        elif current_len > fixed_length:
            s_adjusted = s[:fixed_length, :]
        else:
            s_adjusted = s
        adjusted_list.append(s_adjusted)
    return adjusted_list

def get_transformer_instance(kernel_count, source):
    if source == "aeon":
        return MultiRocketTransformer(n_kernels=kernel_count, random_state=42)
    elif source == "sktime.transformations.panel.rocket": # Hypothetical
        return MultiRocketTransformer(num_kernels=kernel_count, random_state=42)
    raise ValueError(f"Unknown MultiRocket source for instantiation: {source}")

# --- Main MultiRocket-based processing flow for experiments ---
def main_process_multirocket_experiment(
    full_train_info_df, train_txt_folder_path,
    test_info_csv_path, test_txt_folder_path,
    output_folder_path, experiment_params
):
    if MultiRocketTransformer is None: return None

    classifier_type = experiment_params['classifier_type']
    logistic_C = experiment_params.get('logistic_C', 1.0)
    kernel_count = experiment_params['kernel_count']
    apply_instance_norm = experiment_params['instance_norm']
    experiment_id = experiment_params['experiment_id']

    print(f"\n--- Starting Experiment: {experiment_id} ---")
    print(f"Params: Classifier={classifier_type}, C={logistic_C if classifier_type=='logistic' else 'N/A'}, Kernels={kernel_count}, InstanceNorm={apply_instance_norm}, Source={MULTIROCKET_SOURCE}")

    all_raw_series, all_labels, all_uids = [], {'gender_M': [], 'hold_racket_handed_R': [], 'play years': [], 'level': []}, []
    for _, row in full_train_info_df.iterrows():
        uid = str(row['unique_id'])
        # load_and_preprocess_series now returns a 2D NumPy array (n_timepoints, 3)
        series = load_and_preprocess_series(os.path.join(train_txt_folder_path, f"{uid}.txt"), apply_instance_norm=apply_instance_norm)
        if series is not None:
            all_raw_series.append(series); all_uids.append(uid)
            for key, col, val_map in [('gender_M', 'gender', {1:1,0:0}), ('hold_racket_handed_R', 'hold racket handed', {1:1,0:0}),
                                     ('play years', 'play years', None), ('level', 'level', None)]:
                all_labels[key].append(val_map.get(row[col],0) if val_map else row[col])
    if not all_raw_series: print(f"[{experiment_id}] No valid series from full training data."); return None
    for k in all_labels: all_labels[k] = np.array(all_labels[k])
    
    all_uids_np = np.array(all_uids)

    val_scores = {f"val_{t}_score": np.nan for t in ['gender_M', 'hold_racket_handed_R', 'play years', 'level']}
    if len(all_raw_series) >= 2:
        uids_to_original_idx = {uid_val: i for i, uid_val in enumerate(full_train_info_df['unique_id'].astype(str))}
        stratify_column_for_split = []
        for uid_val in all_uids_np:
            original_idx = uids_to_original_idx.get(uid_val)
            if original_idx is not None:
                 stratify_column_for_split.append(full_train_info_df.iloc[original_idx]['level'])
            else:
                 stratify_column_for_split.append(0)
        stratify_column_for_split = np.array(stratify_column_for_split)

        try:
            train_indices, val_indices = train_test_split(np.arange(len(all_raw_series)), test_size=0.2, random_state=42,
                                                          stratify=stratify_column_for_split if len(np.unique(stratify_column_for_split)) >=2 else None)
        except ValueError:
            train_indices, val_indices = train_test_split(np.arange(len(all_raw_series)), test_size=0.2, random_state=42)

        train_ss_raw_series = [all_raw_series[i] for i in train_indices]
        val_raw_series = [all_raw_series[i] for i in val_indices]
        train_ss_labels = {k: v[train_indices] for k, v in all_labels.items()}
        val_labels = {k: v[val_indices] for k, v in all_labels.items()}

        if train_ss_raw_series:
            # Note: len(s) is now s.shape[0] for NumPy arrays
            fixed_len_ss = max(s.shape[0] for s in train_ss_raw_series) if train_ss_raw_series else 0
            if fixed_len_ss > 0:
                # Create 3D NumPy panel for MultiRocket
                adjusted_train_series = adjust_series_length(train_ss_raw_series, fixed_len_ss)
                adjusted_val_series = adjust_series_length(val_raw_series, fixed_len_ss)
                
                # Stack to (n_instances, n_timepoints, n_variables) then transpose to (n_instances, n_variables, n_timepoints)
                X_train_ss_panel = np.stack(adjusted_train_series).transpose(0, 2, 1)
                X_val_panel = np.stack(adjusted_val_series).transpose(0, 2, 1)

                val_multirocket_transformer = get_transformer_instance(kernel_count, MULTIROCKET_SOURCE)
                val_multirocket_transformer.fit(X_train_ss_panel)
                X_train_ss_multirocket = val_multirocket_transformer.transform(X_train_ss_panel)
                X_val_multirocket = val_multirocket_transformer.transform(X_val_panel)

                target_map_val = {'gender_M': 'roc_auc', 'hold_racket_handed_R': 'roc_auc', 'play years': 'accuracy', 'level': 'accuracy'}
                for target, metric in target_map_val.items():
                    y_train_ss_target, y_val_target = train_ss_labels[target], val_labels[target]
                    
                    clf_val_base = None
                    if classifier_type == 'logistic': clf_val_base = LogisticRegression(solver='liblinear', random_state=42, C=logistic_C, max_iter=1000, class_weight='balanced')
                    elif classifier_type == 'ridge': clf_val_base = RidgeClassifierCV(alphas=np.logspace(-3, 3, 10), class_weight='balanced')
                    
                    if clf_val_base is None: continue
                    pipeline_val = make_pipeline(StandardScaler(), clf_val_base)
                    
                    try:
                        pipeline_val.fit(X_train_ss_multirocket, y_train_ss_target)
                        score = np.nan
                        if metric == 'roc_auc':
                            if len(np.unique(y_val_target)) >= 2:
                                if hasattr(pipeline_val, 'predict_proba'):
                                    y_scores_val = pipeline_val.predict_proba(X_val_multirocket)[:, 1]
                                elif hasattr(pipeline_val, 'decision_function'):
                                    y_scores_val = pipeline_val.decision_function(X_val_multirocket)
                                else: continue
                                score = roc_auc_score(y_val_target, y_scores_val)
                            else: print(f"[{experiment_id}] Skipping ROC AUC for {target} on validation: only one class.")
                        else:
                            y_pred_val = pipeline_val.predict(X_val_multirocket)
                            score = accuracy_score(y_val_target, y_pred_val)
                        val_scores[f"val_{target}_score"] = score
                    except Exception as e: print(f"[{experiment_id}] Error during validation for {target}: {e}")
    print(f"[{experiment_id}] Validation Scores: {val_scores}")

    if not all_raw_series: return val_scores
    fixed_len_full = max(s.shape[0] for s in all_raw_series) if all_raw_series else 0
    if fixed_len_full == 0: return val_scores
    
    # Create 3D NumPy panel for final training
    adjusted_all_train_series = adjust_series_length(all_raw_series, fixed_len_full)
    X_all_train_panel = np.stack(adjusted_all_train_series).transpose(0, 2, 1)

    final_multirocket_transformer = get_transformer_instance(kernel_count, MULTIROCKET_SOURCE)
    final_multirocket_transformer.fit(X_all_train_panel)
    X_all_train_multirocket_features = final_multirocket_transformer.transform(X_all_train_panel)

    final_trained_models = {}
    for task_key, actual_label_col in {'gender':'gender_M', 'hold_racket':'hold_racket_handed_R', 'play_years':'play years', 'level':'level'}.items():
        y_all_train_target = all_labels[actual_label_col]
        clf_final_base = None
        if classifier_type == 'logistic':
            clf_final_base = LogisticRegression(solver='liblinear', random_state=42, C=logistic_C, max_iter=1000, class_weight='balanced')
        elif classifier_type == 'ridge':
            base_ridge = RidgeClassifierCV(alphas=np.logspace(-3,3,10), class_weight='balanced')
            clf_final_base = CalibratedClassifierCV(base_ridge, method='sigmoid', cv=3)
        
        if clf_final_base is None: continue
        pipeline_final = make_pipeline(StandardScaler(), clf_final_base)
        try:
            pipeline_final.fit(X_all_train_multirocket_features, y_all_train_target)
            final_trained_models[task_key] = pipeline_final
        except Exception as e: print(f"[{experiment_id}] Error final model training {task_key}: {e}")
    
    test_info_df = pd.read_csv(test_info_csv_path); test_info_df['unique_id'] = test_info_df['unique_id'].astype(str)
    raw_test_series_list, test_ids_processed = [], []
    for _, row in test_info_df.iterrows():
        uid = str(row['unique_id'])
        series = load_and_preprocess_series(os.path.join(test_txt_folder_path, f"{uid}.txt"), apply_instance_norm=apply_instance_norm)
        if series is not None: raw_test_series_list.append(series); test_ids_processed.append(uid)

    X_test_multirocket_features = None
    if raw_test_series_list:
        # Create 3D NumPy panel for test prediction
        adjusted_test_series = adjust_series_length(raw_test_series_list, fixed_len_full)
        X_test_panel = np.stack(adjusted_test_series).transpose(0, 2, 1)
        X_test_multirocket_features = final_multirocket_transformer.transform(X_test_panel)
    else:
        num_output_features = X_all_train_multirocket_features.shape[1] if X_all_train_multirocket_features is not None and X_all_train_multirocket_features.ndim == 2 else kernel_count
        X_test_multirocket_features = np.array([]).reshape(0, num_output_features)

    submission_df = pd.DataFrame({'unique_id': test_info_df['unique_id'].astype(str)})
    play_years_cols_expected_labels = [0, 1, 2]; default_py_prob = 1.0 / len(play_years_cols_expected_labels)
    level_cols_expected_labels = [2, 3, 4, 5]; default_lvl_prob = 1.0 / len(level_cols_expected_labels)
    default_gender_prob = 0.5; default_hold_racket_prob = 0.5
    predictions_processed = {uid: {} for uid in test_ids_processed}

    if X_test_multirocket_features is not None and X_test_multirocket_features.shape[0] > 0:
        for task_key, model_col_name, default_prob, expected_labels in [
            ('gender', 'gender', default_gender_prob, [1]), ('hold_racket', 'hold racket handed', default_hold_racket_prob, [1]),
            ('play_years', 'play years', default_py_prob, play_years_cols_expected_labels),
            ('level', 'level', default_lvl_prob, level_cols_expected_labels)]:
            model = final_trained_models.get(task_key)
            if model:
                probs = model.predict_proba(X_test_multirocket_features)
                model_classes = model.steps[-1][1].classes_ if not isinstance(model.steps[-1][1], CalibratedClassifierCV) else model.steps[-1][1].calibrated_classifiers_[0].estimator.classes_

                for i, uid_test in enumerate(test_ids_processed):
                    if task_key in ['gender', 'hold_racket']:
                        class_idx = np.where(model_classes == expected_labels[0])[0]
                        predictions_processed[uid_test][model_col_name] = probs[i, class_idx[0]] if len(class_idx) > 0 else default_prob
                    else:
                        for cls_label in expected_labels:
                            col_sub = f'{model_col_name}_{cls_label}'
                            class_idx = np.where(model_classes == cls_label)[0]
                            predictions_processed[uid_test][col_sub] = probs[i, class_idx[0]] if len(class_idx) > 0 else default_prob
            else: 
                for uid_test in test_ids_processed:
                    if task_key in ['gender', 'hold_racket']: predictions_processed[uid_test][model_col_name] = default_prob
                    else:
                        for cls_label in expected_labels: predictions_processed[uid_test][f'{model_col_name}_{cls_label}'] = default_prob
    
    submission_df['gender'] = default_gender_prob
    submission_df['hold racket handed'] = default_hold_racket_prob
    for cls_label in play_years_cols_expected_labels: submission_df[f'play years_{cls_label}'] = default_py_prob
    for cls_label in level_cols_expected_labels: submission_df[f'level_{cls_label}'] = default_lvl_prob
    for uid_proc, preds_dict in predictions_processed.items():
        row_idx = submission_df.index[submission_df['unique_id'] == uid_proc]
        if not row_idx.empty:
            for col_name, pred_val in preds_dict.items():
                if col_name in submission_df.columns: submission_df.loc[row_idx[0], col_name] = pred_val
    required_output_cols = ["unique_id", "gender", "hold racket handed"] + \
                           [f'play years_{cls_label}' for cls_label in play_years_cols_expected_labels] + \
                           [f'level_{cls_label}' for cls_label in level_cols_expected_labels]
    for col in required_output_cols:
        if col not in submission_df.columns:
            if "play years" in col: submission_df[col] = default_py_prob
            elif "level" in col: submission_df[col] = default_lvl_prob
            elif col == "gender": submission_df[col] = default_gender_prob
            elif col == "hold racket handed": submission_df[col] = default_hold_racket_prob
    submission_df = submission_df[required_output_cols]
    safe_source_name = MULTIROCKET_SOURCE.replace('.', '_').replace(':', '_') if MULTIROCKET_SOURCE else "unknown_source"
    submission_filename = f"submission_{experiment_id}_clf_{classifier_type}"
    if classifier_type == 'logistic': submission_filename += f"_C{logistic_C}"
    submission_filename += f"_k{kernel_count}_norm{apply_instance_norm}_{safe_source_name}.csv"
    submission_file_path = os.path.join(output_folder_path, submission_filename)
    submission_df.to_csv(submission_file_path, index=False, float_format='%.8f')
    print(f"--- Experiment {experiment_id} Finished. Submission: {submission_file_path} ---")
    return val_scores

if __name__ == '__main__':
    warnings.filterwarnings("ignore", category=UserWarning) 
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    
    base_dir = "."
    actual_train_info_file = os.path.join(base_dir, "data", "pingpong", "train", "train_info.csv")
    actual_train_txt_dir = os.path.join(base_dir, "data", "pingpong", "train")
    actual_test_info_file = os.path.join(base_dir, "data", "pingpong", "test", "test_info.csv")
    actual_test_txt_dir = os.path.join(base_dir, "data", "pingpong", "test")
    main_output_dir = os.path.join(base_dir, "output_multirocket_experiments_validated_v11")
    os.makedirs(main_output_dir, exist_ok=True)
    
    if MultiRocketTransformer is None:
        print("由於 MultiRocket 無法導入，實驗終止。")
    else:
        print(f"所有實驗輸出將儲存於: {os.path.abspath(main_output_dir)}")
        paths_ok = True
        for p_path_check in [actual_train_info_file, actual_train_txt_dir, actual_test_info_file, actual_test_txt_dir]:
            if not os.path.exists(p_path_check): print(f"錯誤: 路徑未找到 {p_path_check}"); paths_ok = False
        
        if paths_ok:
            print("所有輸入路徑檢查完畢，開始執行系列實驗 (包含內部驗證)...")
            full_train_info_df_global = pd.read_csv(actual_train_info_file)
            full_train_info_df_global['unique_id'] = full_train_info_df_global['unique_id'].astype(str)

            classifier_configs = [
               {'type': 'logistic', 'C': 0.005}, {'type': 'logistic', 'C':0.01}, {'type': 'logistic', 'C':0.001} , {'type': 'logistic', 'C':0.0001} , {'type': 'logistic', 'C':0.00001}            
            ]
            kernel_counts = [100,500,600,700,800,900,1000,1500]
            instance_norm_options = [True]
            all_experiment_scores = []
            experiment_number = 0
            total_experiments = len(classifier_configs) * len(kernel_counts) * len(instance_norm_options)
            print(f"總共將執行 {total_experiments} 組實驗。")

            for clf_config in classifier_configs:
                for k_count in kernel_counts:
                    for norm_option in instance_norm_options:
                        experiment_number += 1
                        exp_id = f"exp{experiment_number:03d}"
                        params = {'classifier_type': clf_config['type'], 'kernel_count': k_count,
                                  'instance_norm': norm_option, 'experiment_id': exp_id}
                        if clf_config['type'] == 'logistic': params['logistic_C'] = clf_config['C']

                        validation_scores = main_process_multirocket_experiment(
                            full_train_info_df=full_train_info_df_global,
                            train_txt_folder_path=actual_train_txt_dir,
                            test_info_csv_path=actual_test_info_file,
                            test_txt_folder_path=actual_test_txt_dir,
                            output_folder_path=main_output_dir,
                            experiment_params=params)
                        if validation_scores:
                            scores_to_log = params.copy()
                            scores_to_log.update(validation_scores)
                            all_experiment_scores.append(scores_to_log)
            
            print(f"\n所有 {experiment_number} 個實驗已執行完畢。")
            if all_experiment_scores:
                scores_df = pd.DataFrame(all_experiment_scores)
                scores_csv_path = os.path.join(main_output_dir, "_all_experiment_validation_scores.csv")
                scores_df.to_csv(scores_csv_path, index=False, float_format='%.4f')
                print(f"\n所有實驗的內部驗證分數已儲存至: {scores_csv_path}")
                print("\n驗證分數摘要 (部分顯示):")
                print(scores_df.head())
        else: print("由於路徑錯誤，實驗未執行。")
        print(f"腳本執行完畢。時間: {time.strftime('%Y%m%d_%H%M%S')}")


# In[ ]:




