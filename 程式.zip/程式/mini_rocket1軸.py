#!/usr/bin/env python
# coding: utf-8

# In[3]:


#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import os
from scipy.signal import detrend
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, RidgeClassifierCV
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedGroupKFold # Replaced train_test_split
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.calibration import CalibratedClassifierCV # Import for Ridge probabilities
import time
from tqdm import tqdm
import warnings
import itertools

# --- MiniRocket Transformer Import Logic ---
try:
    from aeon.transformations.collection.convolution_based import MiniRocket as MiniRocketTransformer
    MINIROCKET_SOURCE = "aeon"
except ModuleNotFoundError:
    try:
        from sktime.transformations.panel.rocket import MiniRocket as MiniRocketTransformer
        MINIROCKET_SOURCE = "sktime.transformations.panel.rocket"
    except ModuleNotFoundError:
        try:
            from sktime.transformations.panel.minirocket import MiniRocket as MiniRocketTransformer
            MINIROCKET_SOURCE = "sktime.transformations.panel.minirocket"
        except ModuleNotFoundError:
            try:
                from sktime.transformations.panel.rocket import Rocket as MiniRocketTransformer # Fallback to Rocket
                MINIROCKET_SOURCE = "sktime.transformations.panel.rocket.Rocket"
            except ModuleNotFoundError:
                MiniRocketTransformer = None
print(f"Initializing with Transformer from: {MINIROCKET_SOURCE if MiniRocketTransformer else 'Unavailable'}")
# --- End MiniRocket Import ---

def load_and_preprocess_series(file_path, fs=85.0, min_len_seconds=0.5, apply_instance_norm=False):
    try:
        df = pd.read_csv(file_path, header=None, sep=r'\s+', engine='python')
        if df.shape[1] < 2: return None
        y_raw = df.iloc[:, 1].values
    except Exception: return None
    if len(y_raw) < fs * min_len_seconds: return None
    y_detrended = detrend(y_raw, type='linear')
    if apply_instance_norm:
        std_dev = np.std(y_detrended)
        if std_dev > 1e-7: y_processed = (y_detrended - np.mean(y_detrended)) / std_dev
        else: y_processed = y_detrended
    else: y_processed = y_detrended
    return pd.Series(y_processed.astype(np.float32))

def adjust_series_length(series_list, fixed_length):
    adjusted_list = []
    if not series_list: return adjusted_list
    for s in series_list:
        current_len = len(s)
        if current_len < fixed_length:
            s_adjusted = pd.concat([s, pd.Series(np.zeros(fixed_length - current_len, dtype=s.dtype))], ignore_index=True)
        elif current_len > fixed_length:
            s_adjusted = s.iloc[:fixed_length]
        else: s_adjusted = s
        adjusted_list.append(s_adjusted)
    return adjusted_list

def get_transformer_instance(kernel_count, source):
    # (This function remains the same as your Cell In[11])
    if source == "aeon":
        return MiniRocketTransformer(n_kernels=kernel_count, random_state=42)
    elif source == "sktime.transformations.panel.rocket.Rocket": # Basic Rocket
        return MiniRocketTransformer(num_kernels=kernel_count, random_state=42)
    elif source in ["sktime.transformations.panel.rocket", "sktime.transformations.panel.minirocket"]:
        try: return MiniRocketTransformer(num_kernels=kernel_count, random_state=42)
        except TypeError: return MiniRocketTransformer(num_features=kernel_count, random_state=42)
    raise ValueError(f"Unknown MiniRocket source for instantiation: {source}")

# --- Main ROCKET-based processing flow for experiments ---
def main_process_rocket_experiment(
    full_train_info_df, train_txt_folder_path,
    test_info_csv_path, test_txt_folder_path,
    output_folder_path, experiment_params
):
    if MiniRocketTransformer is None: return None

    classifier_type = experiment_params['classifier_type']
    logistic_C = experiment_params.get('logistic_C', 1.0)
    kernel_count = experiment_params['kernel_count']
    apply_instance_norm = experiment_params['instance_norm']
    experiment_id = experiment_params['experiment_id']
    N_SPLITS_KFOLD = 5 # Number of folds for cross-validation

    print(f"\n--- Starting Experiment: {experiment_id} ---")
    print(f"Params: Classifier={classifier_type}, C={logistic_C if classifier_type=='logistic' else 'N/A'}, Kernels={kernel_count}, InstanceNorm={apply_instance_norm}, Source={MINIROCKET_SOURCE}")

    all_raw_series, all_labels, all_uids = [], {'gender_M': [], 'hold_racket_handed_R': [], 'play years': [], 'level': []}, []
    for _, row in full_train_info_df.iterrows():
        uid = str(row['unique_id'])
        series = load_and_preprocess_series(os.path.join(train_txt_folder_path, f"{uid}.txt"), apply_instance_norm=apply_instance_norm)
        if series is not None:
            all_raw_series.append(series); all_uids.append(uid)
            for key, col, val_map in [('gender_M', 'gender', {1:1,0:0}), ('hold_racket_handed_R', 'hold racket handed', {1:1,0:0}),
                                     ('play years', 'play years', None), ('level', 'level', None)]:
                all_labels[key].append(val_map.get(row[col],0) if val_map else row[col])
    if not all_raw_series: print(f"[{experiment_id}] No valid series from full training data."); return None
    for k in all_labels: all_labels[k] = np.array(all_labels[k])
    
    all_uids_np = np.array(all_uids)

    # *** MODIFICATION START: StratifiedGroupKFold Cross-Validation ***
    val_scores = {f"val_{t}_score": np.nan for t in ['gender_M', 'hold_racket_handed_R', 'play years', 'level']}
    fold_scores = {key: [] for key in val_scores.keys()}

    if len(all_raw_series) >= 2:
        # Prepare groups for K-Fold (one group per unique user)
        # and y for stratification (player's level)
        uids_to_original_idx = {uid_val: i for i, uid_val in enumerate(full_train_info_df['unique_id'].astype(str))}
        stratify_column_for_split = []
        for uid_val in all_uids_np:
            original_idx = uids_to_original_idx.get(uid_val)
            if original_idx is not None:
                 stratify_column_for_split.append(full_train_info_df.iloc[original_idx]['level'])
            else:
                 stratify_column_for_split.append(0)
        stratify_column_for_split = np.array(stratify_column_for_split)

        # Check if stratification is possible
        if len(np.unique(stratify_column_for_split)) < 2:
            print(f"[{experiment_id}] Cannot stratify validation split, not enough class diversity.")
        
        sgkf = StratifiedGroupKFold(n_splits=N_SPLITS_KFOLD, shuffle=True, random_state=42)
        
        # The split is on indices, using 'level' for stratifying and 'uid' for grouping
        fold_iterator = sgkf.split(np.arange(len(all_raw_series)), stratify_column_for_split, groups=all_uids_np)

        for fold_num, (train_indices, val_indices) in enumerate(fold_iterator):
            print(f"[{experiment_id}] Processing Fold {fold_num+1}/{N_SPLITS_KFOLD}...")
            
            train_ss_raw_series = [all_raw_series[i] for i in train_indices]
            val_raw_series = [all_raw_series[i] for i in val_indices]
            train_ss_labels = {k: v[train_indices] for k, v in all_labels.items()}
            val_labels = {k: v[val_indices] for k, v in all_labels.items()}

            if not train_ss_raw_series or not val_raw_series:
                print(f"[{experiment_id}] Skipping fold {fold_num+1} due to empty train/val set.")
                continue

            fixed_len_ss = max(len(s) for s in train_ss_raw_series) if train_ss_raw_series else 0
            if fixed_len_ss > 0:
                X_train_ss_panel = pd.DataFrame(data={"dim_0": adjust_series_length(train_ss_raw_series, fixed_len_ss)})
                X_val_panel = pd.DataFrame(data={"dim_0": adjust_series_length(val_raw_series, fixed_len_ss)})
                val_rocket_transformer = get_transformer_instance(kernel_count, MINIROCKET_SOURCE)
                val_rocket_transformer.fit(X_train_ss_panel)
                X_train_ss_rocket = val_rocket_transformer.transform(X_train_ss_panel)
                X_val_rocket = val_rocket_transformer.transform(X_val_panel)

                target_map_val = {'gender_M': 'roc_auc', 'hold_racket_handed_R': 'roc_auc', 'play years': 'accuracy', 'level': 'accuracy'}
                for target, metric in target_map_val.items():
                    y_train_ss_target, y_val_target = train_ss_labels[target], val_labels[target]
                    
                    clf_val_base = None
                    if classifier_type == 'logistic': clf_val_base = LogisticRegression(solver='liblinear', random_state=42, C=logistic_C, max_iter=1000, class_weight='balanced')
                    elif classifier_type == 'ridge': clf_val_base = RidgeClassifierCV(alphas=np.logspace(-3, 3, 10), class_weight='balanced')
                    
                    if clf_val_base is None: continue
                    pipeline_val = make_pipeline(StandardScaler(), clf_val_base)
                    
                    try:
                        pipeline_val.fit(X_train_ss_rocket, y_train_ss_target)
                        score = np.nan
                        if metric == 'roc_auc':
                            if len(np.unique(y_val_target)) >= 2:
                                if hasattr(pipeline_val, 'predict_proba'):
                                    y_scores_val = pipeline_val.predict_proba(X_val_rocket)[:, 1]
                                elif hasattr(pipeline_val, 'decision_function'):
                                    y_scores_val = pipeline_val.decision_function(X_val_rocket)
                                else: continue
                                score = roc_auc_score(y_val_target, y_scores_val)
                            else: print(f"[{experiment_id}] Skipping ROC AUC for {target} in fold {fold_num+1}: only one class.")
                        else: # accuracy
                            y_pred_val = pipeline_val.predict(X_val_rocket)
                            score = accuracy_score(y_val_target, y_pred_val)
                        fold_scores[f"val_{target}_score"].append(score)
                    except Exception as e: 
                        print(f"[{experiment_id}] Error during validation for {target} in fold {fold_num+1}: {e}")
                        fold_scores[f"val_{target}_score"].append(np.nan)

        # Average the scores across all folds
        for key, scores_list in fold_scores.items():
            if scores_list: # Only average if there are scores
                val_scores[key] = np.nanmean(scores_list)
    
    # *** MODIFICATION END ***
    
    print(f"[{experiment_id}] Averaged Validation Scores: {val_scores}")

    # 4. --- Final Model Training on ALL Training Data & Test Prediction ---
    if not all_raw_series: return val_scores
    fixed_len_full = max(len(s) for s in all_raw_series) if all_raw_series else 0
    if fixed_len_full == 0: return val_scores
    X_all_train_panel = pd.DataFrame(data={"dim_0": adjust_series_length(all_raw_series, fixed_len_full)})
    final_rocket_transformer = get_transformer_instance(kernel_count, MINIROCKET_SOURCE)
    final_rocket_transformer.fit(X_all_train_panel)
    X_all_train_rocket_features = final_rocket_transformer.transform(X_all_train_panel)

    final_trained_models = {}
    for task_key, actual_label_col in {'gender':'gender_M', 'hold_racket':'hold_racket_handed_R', 'play_years':'play years', 'level':'level'}.items():
        y_all_train_target = all_labels[actual_label_col]
        clf_final_base = None
        if classifier_type == 'logistic':
            clf_final_base = LogisticRegression(solver='liblinear', random_state=42, C=logistic_C, max_iter=1000, class_weight='balanced')
        elif classifier_type == 'ridge':
            base_ridge = RidgeClassifierCV(alphas=np.logspace(-3,3,10), class_weight='balanced')
            clf_final_base = CalibratedClassifierCV(base_ridge, method='sigmoid', cv=3)
        
        if clf_final_base is None: continue
        pipeline_final = make_pipeline(StandardScaler(), clf_final_base)
        try:
            pipeline_final.fit(X_all_train_rocket_features, y_all_train_target)
            final_trained_models[task_key] = pipeline_final
        except Exception as e: print(f"[{experiment_id}] Error final model training {task_key}: {e}")
    
    test_info_df = pd.read_csv(test_info_csv_path); test_info_df['unique_id'] = test_info_df['unique_id'].astype(str)
    raw_test_series_list, test_ids_processed = [], []
    for _, row in test_info_df.iterrows():
        uid = str(row['unique_id'])
        series = load_and_preprocess_series(os.path.join(test_txt_folder_path, f"{uid}.txt"), apply_instance_norm=apply_instance_norm)
        if series is not None: raw_test_series_list.append(series); test_ids_processed.append(uid)

    X_test_rocket_features = None
    if raw_test_series_list:
        X_test_panel = pd.DataFrame(data={"dim_0": adjust_series_length(raw_test_series_list, fixed_len_full)})
        X_test_rocket_features = final_rocket_transformer.transform(X_test_panel)
    else:
        num_output_features = X_all_train_rocket_features.shape[1] if X_all_train_rocket_features is not None and X_all_train_rocket_features.ndim == 2 else kernel_count
        X_test_rocket_features = np.array([]).reshape(0, num_output_features)

    submission_df = pd.DataFrame({'unique_id': test_info_df['unique_id'].astype(str)})
    play_years_cols_expected_labels = [0, 1, 2]; default_py_prob = 1.0 / len(play_years_cols_expected_labels)
    level_cols_expected_labels = [2, 3, 4, 5]; default_lvl_prob = 1.0 / len(level_cols_expected_labels)
    default_gender_prob = 0.5; default_hold_racket_prob = 0.5
    predictions_processed = {uid: {} for uid in test_ids_processed}

    if X_test_rocket_features is not None and X_test_rocket_features.shape[0] > 0:
        for task_key, model_col_name, default_prob, expected_labels in [
            ('gender', 'gender', default_gender_prob, [1]), ('hold_racket', 'hold racket handed', default_hold_racket_prob, [1]),
            ('play_years', 'play years', default_py_prob, play_years_cols_expected_labels),
            ('level', 'level', default_lvl_prob, level_cols_expected_labels)]:
            model = final_trained_models.get(task_key)
            if model:
                probs = model.predict_proba(X_test_rocket_features)
                model_classes = model.steps[-1][1].classes_ if not isinstance(model.steps[-1][1], CalibratedClassifierCV) else model.steps[-1][1].calibrated_classifiers_[0].estimator.classes_

                for i, uid_test in enumerate(test_ids_processed):
                    if task_key in ['gender', 'hold_racket']:
                        class_idx = np.where(model_classes == expected_labels[0])[0]
                        predictions_processed[uid_test][model_col_name] = probs[i, class_idx[0]] if len(class_idx) > 0 else default_prob
                    else:
                        for cls_label in expected_labels:
                            col_sub = f'{model_col_name}_{cls_label}'
                            class_idx = np.where(model_classes == cls_label)[0]
                            predictions_processed[uid_test][col_sub] = probs[i, class_idx[0]] if len(class_idx) > 0 else default_prob
            else: 
                for uid_test in test_ids_processed:
                    if task_key in ['gender', 'hold_racket']: predictions_processed[uid_test][model_col_name] = default_prob
                    else:
                        for cls_label in expected_labels: predictions_processed[uid_test][f'{model_col_name}_{cls_label}'] = default_prob
    
    submission_df['gender'] = default_gender_prob
    submission_df['hold racket handed'] = default_hold_racket_prob
    for cls_label in play_years_cols_expected_labels: submission_df[f'play years_{cls_label}'] = default_py_prob
    for cls_label in level_cols_expected_labels: submission_df[f'level_{cls_label}'] = default_lvl_prob
    for uid_proc, preds_dict in predictions_processed.items():
        row_idx = submission_df.index[submission_df['unique_id'] == uid_proc]
        if not row_idx.empty:
            for col_name, pred_val in preds_dict.items():
                if col_name in submission_df.columns: submission_df.loc[row_idx[0], col_name] = pred_val
    required_output_cols = ["unique_id", "gender", "hold racket handed"] +                            [f'play years_{cls_label}' for cls_label in play_years_cols_expected_labels] +                            [f'level_{cls_label}' for cls_label in level_cols_expected_labels]
    for col in required_output_cols:
        if col not in submission_df.columns:
            if "play years" in col: submission_df[col] = default_py_prob
            elif "level" in col: submission_df[col] = default_lvl_prob
            elif col == "gender": submission_df[col] = default_gender_prob
            elif col == "hold racket handed": submission_df[col] = default_hold_racket_prob
    submission_df = submission_df[required_output_cols]
    safe_source_name = MINIROCKET_SOURCE.replace('.', '_').replace(':', '_') if MINIROCKET_SOURCE else "unknown_source"
    submission_filename = f"submission_{experiment_id}_clf_{classifier_type}"
    if classifier_type == 'logistic': submission_filename += f"_C{logistic_C}"
    submission_filename += f"_k{kernel_count}_norm{apply_instance_norm}_{safe_source_name}.csv"
    submission_file_path = os.path.join(output_folder_path, submission_filename)
    submission_df.to_csv(submission_file_path, index=False, float_format='%.8f')
    print(f"--- Experiment {experiment_id} Finished. Submission: {submission_file_path} ---")
    return val_scores

if __name__ == '__main__':
    # (Main experiment loop remains the same as your Cell In[11])
    warnings.filterwarnings("ignore", category=UserWarning) 
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    
    base_dir = "."
    actual_train_info_file = os.path.join(base_dir, "data", "pingpong", "train", "train_info.csv")
    actual_train_txt_dir = os.path.join(base_dir, "data", "pingpong", "train")
    actual_test_info_file = os.path.join(base_dir, "data", "pingpong", "test", "test_info.csv")
    actual_test_txt_dir = os.path.join(base_dir, "data", "pingpong", "test")
    main_output_dir = os.path.join(base_dir, "output_minirocket_experiments_validated_v6") # New folder
    os.makedirs(main_output_dir, exist_ok=True)
    
    if MiniRocketTransformer is None:
        print("由於 MiniRocket/Rocket 無法導入，實驗終止。")
    else:
        print(f"所有實驗輸出將儲存於: {os.path.abspath(main_output_dir)}")
        paths_ok = True
        for p_path_check in [actual_train_info_file, actual_train_txt_dir, actual_test_info_file, actual_test_txt_dir]:
            if not os.path.exists(p_path_check): print(f"錯誤: 路徑未找到 {p_path_check}"); paths_ok = False
        
        if paths_ok:
            print("所有輸入路徑檢查完畢，開始執行系列實驗 (包含內部驗證)...")
            full_train_info_df_global = pd.read_csv(actual_train_info_file)
            full_train_info_df_global['unique_id'] = full_train_info_df_global['unique_id'].astype(str)

            classifier_configs = [
                {'type': 'logistic', 'C': 10}, {'type': 'logistic', 'C': 1}, {'type': 'logistic', 'C': 0.1}, {'type': 'logistic', 'C':0.01}, {'type': 'logistic', 'C':0.001} , {'type': 'logistic', 'C':0.0001} , {'type': 'logistic', 'C':0.00001}            
            ]
            kernel_counts = [100,500,600,700,800,900,1000,1500,2000,2500,3000,3500, 4000,5000,7000,10000,15000]
            instance_norm_options = [True,False]
            all_experiment_scores = []
            experiment_number = 0
            total_experiments = len(classifier_configs) * len(kernel_counts) * len(instance_norm_options)
            print(f"總共將執行 {total_experiments} 組實驗。")

            for clf_config in classifier_configs:
                for k_count in kernel_counts:
                    for norm_option in instance_norm_options:
                        experiment_number += 1
                        exp_id = f"exp{experiment_number:03d}"
                        params = {'classifier_type': clf_config['type'], 'kernel_count': k_count,
                                  'instance_norm': norm_option, 'experiment_id': exp_id}
                        if clf_config['type'] == 'logistic': params['logistic_C'] = clf_config['C']

                        validation_scores = main_process_rocket_experiment(
                            full_train_info_df=full_train_info_df_global,
                            train_txt_folder_path=actual_train_txt_dir,
                            test_info_csv_path=actual_test_info_file,
                            test_txt_folder_path=actual_test_txt_dir,
                            output_folder_path=main_output_dir,
                            experiment_params=params)
                        if validation_scores:
                            scores_to_log = params.copy()
                            scores_to_log.update(validation_scores)
                            all_experiment_scores.append(scores_to_log)
            
            print(f"\n所有 {experiment_number} 個實驗已執行完畢。")
            if all_experiment_scores:
                scores_df = pd.DataFrame(all_experiment_scores)
                scores_csv_path = os.path.join(main_output_dir, "_all_experiment_validation_scores.csv")
                scores_df.to_csv(scores_csv_path, index=False, float_format='%.4f')
                print(f"\n所有實驗的內部驗證分數已儲存至: {scores_csv_path}")
                print("\n驗證分數摘要 (部分顯示):")
                print(scores_df.head())
        else: print("由於路徑錯誤，實驗未執行。")
        print(f"腳本執行完畢。時間: {time.strftime('%Y%m%d_%H%M%S')}")


# In[ ]:






# In[ ]:


# In[ ]:




