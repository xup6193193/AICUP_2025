#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pandas as pd
import numpy as np
import os
import ast
from scipy import stats
from scipy.fft import rfft, rfftfreq
from sklearn.model_selection import GridSearchCV, GroupKFold, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, OneHotEncoder # <--- 引入 OneHotEncoder
from sklearn.compose import ColumnTransformer # <--- 引入 ColumnTransformer
from sklearn.pipeline import Pipeline # <--- 引入 Pipeline
from sklearn.metrics import roc_auc_score, make_scorer
from sklearn.exceptions import ConvergenceWarning
import warnings
from datetime import datetime
import joblib

# --- 設定 (與前一版相同) ---
BASE_DATA_PATH = "data/pingpong/"
TRAIN_DIR = os.path.join(BASE_DATA_PATH, "train")
TEST_DIR = os.path.join(BASE_DATA_PATH, "test")
TRAIN_INFO_FILE = os.path.join(TRAIN_DIR, "train_info.csv")
TEST_INFO_FILE = os.path.join(TEST_DIR, "test_info.csv")
TARGET_COLUMNS = {"gender": "gender_male", "hold racket handed": "handed_right", "play years": "play_years", "level": "level"}
OUTPUT_COL_GENDER = "gender"; OUTPUT_COL_HANDED = "hold racket handed"; OUTPUT_COL_YEARS_PREFIX = "play years_"; OUTPUT_COL_LEVEL_PREFIX = "level_"
PLAY_YEARS_CLASSES_REF = [0, 1, 2]; LEVEL_CLASSES_REF = [2, 3, 4, 5]
warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=UserWarning, module='sklearn')
warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)
warnings.filterwarnings("ignore", category=FutureWarning, module='sklearn.metrics._scorer')

# --- 資料載入工具 (與前一版相同) ---
def load_sensor_data(file_path):
    try:
        data = pd.read_csv(file_path, sep=" ", header=None, skipinitialspace=True, on_bad_lines='skip')
        if data.empty or data.shape[1] != 6 :
            data = pd.read_csv(file_path, header=None, on_bad_lines='skip')
            if data.empty: return None
            if data.shape[1] == 1:
                data_values = []
                for _, row_series in data.iterrows():
                    row_str = str(row_series.iloc[0])
                    try:
                        split_values = [float(x) for x in row_str.split() if x]
                        if len(split_values) == 6: data_values.append(split_values)
                    except ValueError: continue
                if not data_values: return None
                data = pd.DataFrame(data_values)
            elif data.shape[1] != 6 : return None
        if data.shape[1] == 6:
            data.columns = ['Ax', 'Ay', 'Az', 'Gx', 'Gy', 'Gz']
            for col in data.columns: data[col] = pd.to_numeric(data[col], errors='coerce')
            if data.isnull().all().all(): return None
            return data.values
        else: return None
    except pd.errors.EmptyDataError: return None
    except Exception: return None

def parse_cut_points(cut_point_str):
    if not isinstance(cut_point_str, str):
        if isinstance(cut_point_str, (list, np.ndarray)):
            try: return [int(p) for p in cut_point_str]
            except (ValueError, TypeError): return []
        return []
    try:
        cleaned_str = cut_point_str.strip()
        if cleaned_str.startswith('[') and cleaned_str.endswith(']'):
            cleaned_str = cleaned_str[1:-1].strip()
        points = []
        for p_str in cleaned_str.split(' '):
            p_str_cleaned = p_str.strip()
            if p_str_cleaned and p_str_cleaned.lstrip('-').isdigit():
                points.append(int(p_str_cleaned))
        if not points and cleaned_str:
             evaluated_list = ast.literal_eval(cut_point_str)
             if isinstance(evaluated_list, list): return [int(p) for p in evaluated_list]
             return []
        return points
    except Exception: pass
    return []

# --- 2. 特徵工程 (簡化統計 + 擴展核心 FFT) (與前一版相同) ---
def get_basic_stats(series, prefix):
    features = {}
    stats_to_init = ['mean', 'std', 'median', 'min', 'max', 'iqr']
    series_clean = series.dropna()
    if series_clean.empty:
        for stat_name in stats_to_init: features[f'{prefix}_{stat_name}'] = 0.0
        return features
    features[f'{prefix}_mean'] = series_clean.mean()
    features[f'{prefix}_std'] = series_clean.std(ddof=0)
    features[f'{prefix}_median'] = series_clean.median()
    features[f'{prefix}_min'] = series_clean.min()
    features[f'{prefix}_max'] = series_clean.max()
    features[f'{prefix}_iqr'] = stats.iqr(series_clean) if not series_clean.empty else 0.0
    return {k: (0.0 if pd.isna(v) else v) for k, v in features.items()}

def get_expanded_core_fft_features(series, prefix, sampling_rate=85):
    features = {}
    keys_to_extract = ['spectral_energy', 'dom_freq', 'mean_freq', 'median_freq', 'spectral_entropy']
    series_clean = series.dropna()
    N = len(series_clean)
    for k_init in keys_to_extract:
        features[f'{prefix}_fft_{k_init}'] = 0.0
    if N < 2: return features
    yf = rfft(series_clean.values)
    xf = rfftfreq(N, 1 / sampling_rate)
    magnitudes = np.abs(yf)
    if len(magnitudes) == 0 or np.sum(magnitudes) < 1e-9 or N == 0: return features
    if 'dom_freq' in keys_to_extract:
        features[f'{prefix}_fft_dom_freq'] = xf[np.argmax(magnitudes)] if len(magnitudes) > 0 and len(xf) > 0 else 0.0
    if 'spectral_energy' in keys_to_extract:
        features[f'{prefix}_fft_spectral_energy'] = np.sum(magnitudes**2) / N if N > 0 else 0.0
    sum_magnitudes = np.sum(magnitudes)
    if 'mean_freq' in keys_to_extract:
        features[f'{prefix}_fft_mean_freq'] = np.sum(xf * magnitudes) / sum_magnitudes if sum_magnitudes > 1e-9 else 0.0
    if 'median_freq' in keys_to_extract:
        cumulative_magnitudes = np.cumsum(magnitudes)
        median_freq_idx = np.searchsorted(cumulative_magnitudes, cumulative_magnitudes[-1] / 2) if len(cumulative_magnitudes) > 0 else 0
        features[f'{prefix}_fft_median_freq'] = xf[median_freq_idx] if median_freq_idx < len(xf) and len(xf) > 0 else (xf[-1] if len(xf) > 0 else 0.0)
    if 'spectral_entropy' in keys_to_extract:
        psd_norm = (magnitudes**2) / np.sum(magnitudes**2) if np.sum(magnitudes**2) > 1e-9 else np.array([])
        psd_norm = psd_norm[psd_norm > 1e-12]
        features[f'{prefix}_fft_spectral_entropy'] = -np.sum(psd_norm * np.log2(psd_norm)) if len(psd_norm) > 0 else 0.0
    return {k: (0.0 if pd.isna(v) else v) for k, v in features.items()}

def extract_features_for_id(sensor_data_np, parsed_cut_points_for_id):
    all_features = {}
    dummy_series = pd.Series([], dtype=float)
    sensor_cols = ['Ax', 'Ay', 'Az', 'Gx', 'Gy', 'Gz']
    if sensor_data_np is None or sensor_data_np.shape[0] == 0:
        for col_name in sensor_cols:
            all_features.update(get_basic_stats(dummy_series, f"full_{col_name}"))
            all_features.update(get_expanded_core_fft_features(dummy_series, f"full_{col_name}"))
        return all_features
    sensor_df = pd.DataFrame(sensor_data_np, columns=sensor_cols)
    for col in sensor_df.columns:
        if sensor_df[col].isnull().any():
            median_val = sensor_df[col].median()
            if pd.isna(median_val): median_val = 0
            sensor_df[col] = sensor_df[col].fillna(median_val)
    for col in sensor_df.columns:
        all_features.update(get_basic_stats(sensor_df[col], f"full_{col}"))
        all_features.update(get_expanded_core_fft_features(sensor_df[col], f"full_{col}"))
    return all_features

# --- 3. 資料處理流程 (create_feature_set 中的提示訊息更新) ---
def create_feature_set(info_df, data_dir):
    all_ids_features_list = []
    print(f"開始為 {data_dir} 中的 {len(info_df)} 個樣本提取特徵 (簡化統計+擴展核心FFT)...")
    for index, row in info_df.iterrows():
        unique_id = row['unique_id']
        txt_file_path = os.path.join(data_dir, f"{unique_id}.txt")
        sensor_data_np = load_sensor_data(txt_file_path)
        parsed_cut_points_for_this_id = parse_cut_points(row['cut_point'])
        features = extract_features_for_id(sensor_data_np, parsed_cut_points_for_this_id)
        features['unique_id'] = unique_id
        all_ids_features_list.append(features)
        if (index + 1) % 200 == 0 or (index + 1) == len(info_df):
            print(f"  已處理 {index+1}/{len(info_df)} 個檔案...")
    feature_df = pd.DataFrame(all_ids_features_list)
    if 'unique_id' not in feature_df.columns and not info_df.empty :
        feature_df['unique_id'] = info_df['unique_id']
    info_df['unique_id'] = info_df['unique_id'].astype(str)
    if 'unique_id' in feature_df.columns:
        feature_df['unique_id'] = feature_df['unique_id'].astype(str)
    else:
        print("警告：feature_df 中缺少 'unique_id' 欄，無法與 info_df 合併。")
        if info_df.empty: return pd.DataFrame()
        feature_df['unique_id'] = info_df['unique_id']
        for col_name in feature_df.columns:
            if col_name != 'unique_id': feature_df[col_name] = np.nan
    # 將 info_df（包含 mode）與 feature_df 合併
    merged_df = pd.merge(info_df, feature_df, on="unique_id", how="left")
    return merged_df

def preprocess_targets(df):
    df_processed = df.copy()
    if 'gender' in df_processed.columns:
        df_processed[TARGET_COLUMNS["gender"]] = df_processed['gender'].map({1: 1, 2: 0}).fillna(df_processed['gender'])
    if 'hold racket handed' in df_processed.columns:
        df_processed[TARGET_COLUMNS["hold racket handed"]] = df_processed['hold racket handed'].map({1: 1, 2: 0}).fillna(df_processed['hold racket handed'])
    if 'play years' in df_processed.columns:
         df_processed[TARGET_COLUMNS["play years"]] = df_processed['play years']
    if 'level' in df_processed.columns:
         df_processed[TARGET_COLUMNS["level"]] = df_processed['level']
    return df_processed

def treat_outliers_iqr_clipping(df_to_clip, df_fit_on, feature_cols):
    df_processed = df_to_clip.copy()
    clipping_params = {}
    for col in feature_cols:
        if col in df_fit_on.columns and pd.api.types.is_numeric_dtype(df_fit_on[col]) and not df_fit_on[col].isnull().all():
            series_fit = df_fit_on[col].dropna()
            if series_fit.empty: continue
            q1, q3 = series_fit.quantile(0.25), series_fit.quantile(0.75)
            iqr = q3 - q1
            lower_bound, upper_bound = (q1 - 1.5 * iqr, q3 + 1.5 * iqr) if iqr > 1e-9 else (q1, q3)
            clipping_params[col] = (lower_bound, upper_bound)
            if col in df_processed.columns: df_processed[col] = np.clip(df_processed[col], lower_bound, upper_bound)
    return df_processed, clipping_params

# --- 4. 模型訓練與預測 (恢復使用 GridSearchCV 搜索 C 值) ---
def train_single_target_model_with_gridsearch(X_train, y_train, groups, target_name_actual_modeling,
                                              random_state=42):
    print(f"\n--- 正在為目標進行訓練 (GridSearchCV, GroupKFold): {target_name_actual_modeling} ---")
    if y_train.isnull().all():
        print(f"目標 {target_name_actual_modeling} 的所有值均為 NaN。跳過訓練。")
        return None, pd.Series(dtype='float64'), 0.0
    valid_indices = y_train.dropna().index
    if len(valid_indices) < 20:
        print(f"目標 {target_name_actual_modeling} 的非 NaN 樣本數過少 ({len(valid_indices)})。跳過穩健訓練。")
        return None, pd.Series(dtype='float64'), 0.0
    X_train_target, y_train_target = X_train.loc[valid_indices], y_train.loc[valid_indices]
    groups_target = groups.loc[valid_indices] if groups is not None else None
    if X_train_target.empty:
        print(f"目標 {target_name_actual_modeling} 在篩選 NaN 後的 X_train 為空。跳過訓練。")
        return None, pd.Series(dtype='float64'), 0.0

    base_estimator = LogisticRegression(penalty='l1', solver='liblinear', class_weight='balanced',
                                        random_state=random_state, max_iter=5000)
    param_grid = { 'C': [0.0005, 0.001, 0.005, 0.01, 0.02, 0.05, 0.1] }
    expected_labels_for_target = None; is_multiclass = False
    if target_name_actual_modeling == TARGET_COLUMNS["play years"]:
        expected_labels_for_target = PLAY_YEARS_CLASSES_REF; is_multiclass = True
    elif target_name_actual_modeling == TARGET_COLUMNS["level"]:
        expected_labels_for_target = LEVEL_CLASSES_REF; is_multiclass = True
    best_model_to_return = None; cv_score_mean = 0.0
    n_groups = len(np.unique(groups_target)) if groups_target is not None else 0
    cv_splits = min(5, n_groups) if groups_target is not None and n_groups > 1 else 5
    use_group_kfold = groups_target is not None and cv_splits >= 2
    cv_strategy = None; fit_params = {}

    if not use_group_kfold :
        print(f"為目標 {target_name_actual_modeling} 無法使用 GroupKFold (組數: {n_groups})。將使用 StratifiedKFold。")
        unique_classes_count_skf = y_train_target.nunique()
        min_samples_per_class_skf = y_train_target.value_counts().min() if unique_classes_count_skf > 0 else 0
        cv_splits_skf = 5
        if unique_classes_count_skf < cv_splits_skf or min_samples_per_class_skf < cv_splits_skf:
            cv_splits_skf = max(2, min(unique_classes_count_skf, min_samples_per_class_skf) if unique_classes_count_skf > 0 else 2)
        if cv_splits_skf < 2:
            print(f"  目標 {target_name_actual_modeling} (StratifiedKFold 回退) 也無法劃分足夠的折數。使用預設參數訓練基礎模型。")
            best_model_to_return = base_estimator.set_params(C=0.01)
            try: best_model_to_return.fit(X_train_target, y_train_target)
            except Exception as fit_e:
                print(f"    基礎模型擬合 (StratifiedKFold 回退) 時出錯 for {target_name_actual_modeling}: {fit_e}")
                return None, pd.Series(dtype='float64'), 0.0
        else: cv_strategy = StratifiedKFold(n_splits=cv_splits_skf, shuffle=True, random_state=random_state)
    else:
        cv_strategy = GroupKFold(n_splits=cv_splits)
        fit_params = {'groups': groups_target}

    current_scoring = 'roc_auc'
    if is_multiclass and expected_labels_for_target is not None:
        def micro_roc_auc_with_fixed_labels_cv(y_true_fold, y_score_fold):
            unique_true_in_fold = pd.Series(y_true_fold).nunique()
            if unique_true_in_fold < 2 or y_score_fold.ndim == 1 or y_score_fold.shape[1] != len(expected_labels_for_target): return 0.5
            try: return roc_auc_score(y_true_fold, y_score_fold, multi_class='ovr', average='micro', labels=expected_labels_for_target)
            except ValueError: return 0.5
        current_scoring = make_scorer(micro_roc_auc_with_fixed_labels_cv, response_method="predict_proba", greater_is_better=True)
    elif is_multiclass: current_scoring = 'roc_auc_ovr'

    if best_model_to_return is None:
        try:
            grid_search = GridSearchCV(base_estimator, param_grid, cv=cv_strategy, scoring=current_scoring, n_jobs=-1, error_score=0.0)
            grid_search.fit(X_train_target, y_train_target, **fit_params)
            best_model_to_return = grid_search.best_estimator_
            cv_score_mean = grid_search.best_score_
            print(f"  目標 {target_name_actual_modeling} (GridSearchCV) 的最佳參數 C: {best_model_to_return.get_params()['C']}")
            print(f"  目標 {target_name_actual_modeling} (GridSearchCV) 的最佳 CV 分數: {cv_score_mean:.4f}")
        except Exception as e:
            print(f"  目標 {target_name_actual_modeling} 在 GridSearchCV 期間發生錯誤: {e}。使用預設參數訓練基礎模型。")
            best_model_to_return = base_estimator.set_params(C=0.01)
            try: best_model_to_return.fit(X_train_target, y_train_target)
            except Exception as fit_e_fallback:
                print(f"    基礎模型回退擬合時出錯 for {target_name_actual_modeling}: {fit_e_fallback}")
                return None, pd.Series(dtype='float64'), 0.0
    if best_model_to_return is not None and not hasattr(best_model_to_return, "classes_"):
        try: best_model_to_return.fit(X_train_target, y_train_target)
        except Exception as final_fit_e:
            print(f" 最終擬合最佳模型時出錯 for {target_name_actual_modeling}: {final_fit_e}")
            return None, pd.Series(dtype='float64'), cv_score_mean
    if best_model_to_return is not None and hasattr(best_model_to_return, 'coef_'):
        coef = best_model_to_return.coef_
        importances = pd.Series(np.mean(np.abs(coef), axis=0) if coef.ndim > 1 else np.abs(coef[0]), index=X_train_target.columns)
        importances = importances.sort_values(ascending=False)
    else: importances = pd.Series(dtype='float64')
    return best_model_to_return, importances, cv_score_mean

# --- 主要執行邏輯 ---
if __name__ == "__main__":
    run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    print("正在載入 info 檔案...")
    train_info_df_orig = pd.read_csv(TRAIN_INFO_FILE)
    test_info_df_orig = pd.read_csv(TEST_INFO_FILE)

    print("\n--- 正在創建訓練集特徵 (簡化統計+擴展核心FFT) ---")
    train_df_features_raw = create_feature_set(train_info_df_orig.copy(), TRAIN_DIR) # 保留原始 info 中的 mode
    print("\n--- 正在創建測試集特徵 (簡化統計+擴展核心FFT) ---")
    test_df_features_raw = create_feature_set(test_info_df_orig.copy(), TEST_DIR) # 保留原始 info 中的 mode

    # *** 修改：定義不包含 'mode' 的數值特徵欄位，以及 'mode' 本身 ***
    cols_to_exclude_from_numeric_features = set(TARGET_COLUMNS.values()) | {'unique_id', 'player_id', 'mode', 'cut_point'}
    cols_to_exclude_from_numeric_features.update(TARGET_COLUMNS.keys())
    
    numeric_feature_cols = []
    if not train_df_features_raw.empty:
        numeric_feature_cols = [
            col for col in train_df_features_raw.columns
            if col not in cols_to_exclude_from_numeric_features and train_df_features_raw[col].nunique(dropna=False) > 1
        ]
        if not numeric_feature_cols :
            numeric_feature_cols = [col for col in train_df_features_raw.columns if col not in cols_to_exclude_from_numeric_features]
    else: print("警告：train_df_features_raw 為空，無法提取數值特徵欄位。")
    
    categorical_feature_cols = ['mode'] # 假設 'mode' 是我們唯一要獨熱編碼的類別特徵

    print(f"\n已識別 {len(numeric_feature_cols)} 個初始數值特徵欄位。")
    if numeric_feature_cols: print(f"前5個數值特徵欄位: {numeric_feature_cols[:5]}")
    print(f"類別特徵欄位: {categorical_feature_cols}")


    # --- 預處理數值特徵 (NaN填充, 縮放) 和類別特徵 (獨熱編碼) ---
    # 1. 填充 NaN (數值特徵用中位數，類別特徵用一個特殊值例如 '__UNKNOWN__')
    print("正在處理 NaN 值...")
    for col in numeric_feature_cols:
        median_val = train_df_features_raw[col].median()
        if pd.isna(median_val): median_val = 0.0
        train_df_features_raw[col] = train_df_features_raw[col].fillna(median_val)
        if col in test_df_features_raw.columns:
             test_df_features_raw[col] = test_df_features_raw[col].fillna(median_val)
        elif col in test_df_features_raw.columns: # 應該不會發生，但作為防護
             test_df_features_raw[col] = test_df_features_raw[col].fillna(0.0)

    for col in categorical_feature_cols: # 例如 'mode'
        # 確保訓練集和測試集都有 'mode' 欄位，如果某個DataFrame沒有，則添加並填充缺失值
        if col not in train_df_features_raw.columns: train_df_features_raw[col] = '__MISSING__'
        if col not in test_df_features_raw.columns: test_df_features_raw[col] = '__MISSING__'
        
        train_df_features_raw[col] = train_df_features_raw[col].astype(str).fillna('__UNKNOWN__')
        if col in test_df_features_raw.columns:
            test_df_features_raw[col] = test_df_features_raw[col].astype(str).fillna('__UNKNOWN__')


    # 2. 預處理目標變數 (在包含所有原始欄位的 DataFrame 上操作)
    train_df_processed = preprocess_targets(train_df_features_raw) # train_df_features_raw 此時包含 mode

    # 3. 異常值處理 (只對數值特徵)
    train_df_outl, clipping_rules = treat_outliers_iqr_clipping(
        train_df_processed.copy(),
        train_df_processed[numeric_feature_cols] if numeric_feature_cols and not train_df_processed.empty else pd.DataFrame(),
        numeric_feature_cols
    )
    test_df_outl = test_df_features_raw.copy() # 使用包含 mode 的 test_df_features_raw
    if not test_df_outl.empty:
        for col, (lower, upper) in clipping_rules.items():
             if col in test_df_outl.columns and col in numeric_feature_cols:
                test_df_outl[col] = np.clip(test_df_outl[col], lower, upper)

    # 4. 創建預處理管道 (結合數值特徵縮放和類別特徵獨熱編碼)
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numeric_feature_cols),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_feature_cols) # sparse_output=False 使得輸出是密集矩陣
        ],
        remainder='drop' # 或者 'passthrough' 如果想保留其他非特徵欄位 (但不建議用於X)
    )

    # 準備 X_train 和 X_test (在應用預處理器之前，它們應該只包含特徵欄位)
    # 注意：'player_id' 和 'unique_id' 以及目標變數不應包含在傳給 preprocessor.fit_transform 的 X 中
    
    # 確保 train_df_outl 和 test_df_outl 有 'mode' 欄位
    if 'mode' not in train_df_outl.columns: train_df_outl['mode'] = '__UNKNOWN__'
    if 'mode' not in test_df_outl.columns: test_df_outl['mode'] = '__UNKNOWN__'


    X_train_to_preprocess = train_df_outl[numeric_feature_cols + categorical_feature_cols]
    X_test_to_preprocess = test_df_outl[numeric_feature_cols + categorical_feature_cols]


    print("正在使用 ColumnTransformer 進行特徵預處理 (縮放和獨熱編碼)...")
    X_train_full_prepared_np = preprocessor.fit_transform(X_train_to_preprocess)
    X_test_prepared_np = preprocessor.transform(X_test_to_preprocess)

    # 獲取獨熱編碼後的特徵名稱
    try:
        ohe_feature_names = preprocessor.named_transformers_['cat'].get_feature_names_out(categorical_feature_cols)
        all_prepared_feature_names = numeric_feature_cols + list(ohe_feature_names)
    except AttributeError: # 舊版 sklearn 可能沒有 get_feature_names_out
        print("警告：無法獲取 OneHotEncoder 的特徵名稱，將使用通用名稱。")
        # 創建通用名稱
        num_ohe_features = X_train_full_prepared_np.shape[1] - len(numeric_feature_cols)
        ohe_feature_names = [f"mode_ohe_{i}" for i in range(num_ohe_features)]
        all_prepared_feature_names = numeric_feature_cols + list(ohe_feature_names)


    X_train_full_prepared = pd.DataFrame(X_train_full_prepared_np, columns=all_prepared_feature_names, index=X_train_to_preprocess.index)
    X_test_prepared = pd.DataFrame(X_test_prepared_np, columns=all_prepared_feature_names, index=X_test_to_preprocess.index)

    print(f"預處理後訓練集特徵維度: {X_train_full_prepared.shape}")
    print(f"預處理後測試集特徵維度: {X_test_prepared.shape}")
    if not X_train_full_prepared.empty:
         print(f"預處理後的前5個特徵欄位: {X_train_full_prepared.columns.tolist()[:5]}")

    # 保存 preprocessor
    joblib.dump(preprocessor, f'preprocessor_with_mode_{run_timestamp}.joblib')
    print(f"預處理器已儲存至 preprocessor_with_mode_{run_timestamp}.joblib")


    train_groups = None
    if 'player_id' in train_df_outl.columns: # train_df_outl 是預處理目標和異常值後的完整訓練數據
        train_groups = train_df_outl['player_id']
        if train_groups.isnull().any():
            train_groups = train_groups.fillna('__MISSING_PLAYER_ID__')
        print(f"已準備 'player_id' 作為 GroupKFold 的分組依據。唯一組的數量: {train_groups.nunique()}")
    else: print("警告：訓練數據 train_df_outl 中未找到 'player_id'。GroupKFold 將無法使用，模型訓練將回退到 StratifiedKFold。")

    print("\n--- 模型訓練 (GridSearchCV 搜索 C, 包含 mode 特徵, 嘗試使用 GroupKFold) ---")
    final_models_to_use = {}
    all_final_feature_importances = {}
    local_cv_scores_summary = {}
    if not X_train_full_prepared.empty:
        for original_target_col_name_key, processed_target_col_name_value in TARGET_COLUMNS.items():
            if processed_target_col_name_value in train_df_outl.columns: # 使用 train_df_outl 獲取 y
                y_train_current_target = train_df_outl[processed_target_col_name_value]
                current_groups_for_train = train_groups if train_groups is not None else pd.Series(index=X_train_full_prepared.index) # 確保索引對齊
                
                # 確保 X_train_full_prepared 和 y_train_current_target 的索引一致，以便 current_groups_for_train 對齊
                common_index = X_train_full_prepared.index.intersection(y_train_current_target.index)
                X_train_for_fit = X_train_full_prepared.loc[common_index]
                y_train_for_fit = y_train_current_target.loc[common_index]
                groups_for_fit = current_groups_for_train.loc[common_index] if current_groups_for_train is not None else None


                model, importances, cv_score = train_single_target_model_with_gridsearch(
                    X_train_for_fit, y_train_for_fit, groups_for_fit, # 使用對齊後的數據
                    processed_target_col_name_value
                )
                final_models_to_use[processed_target_col_name_value] = model
                all_final_feature_importances[processed_target_col_name_value] = importances
                local_cv_scores_summary[processed_target_col_name_value] = cv_score
                if model: joblib.dump(model, f'model_with_mode_{processed_target_col_name_value}_{run_timestamp}.joblib')
    else: print("警告：X_train_full_prepared 為空，跳過模型訓練。")

    # ... (後續的特徵重要性儲存、測試集預測、訓練集評估邏輯與前一版相似) ...
    # ... 主要確保在預測和評估時，X_test_prepared 和 X_train_full_prepared 包含了獨熱編碼後的 mode 特徵 ...

    if local_cv_scores_summary:
        print("\n--- 本地交叉驗證分數總結 (包含 mode 特徵) ---")
        total_cv_score = 0; num_valid_scores = 0
        for target, score in local_cv_scores_summary.items():
            print(f"  目標 {target}: CV 分數 = {score:.4f}")
            if score > 0: total_cv_score += score; num_valid_scores +=1
        if num_valid_scores > 0: print(f"  平均本地 CV 分數: {total_cv_score / num_valid_scores:.4f}")

    if all_final_feature_importances:
        final_importance_df_list = []
        # ... (與前一版相同的儲存邏輯)
        for target_name_final, imp_series_final in all_final_feature_importances.items():
            if imp_series_final is not None and not imp_series_final.empty:
                temp_df_final = imp_series_final.reset_index()
                temp_df_final.columns = ['feature', 'importance']
                temp_df_final['target'] = target_name_final
                final_importance_df_list.append(temp_df_final)
        if final_importance_df_list:
            final_importances_df = pd.concat(final_importance_df_list)
            final_importance_filename = f"feature_importances_with_mode_model_{run_timestamp}.csv"
            final_importances_df.to_csv(final_importance_filename, index=False)
            print(f"\n(包含 mode 特徵)模型的特徵重要性已儲存至 {final_importance_filename}")
        else: print("\n(包含 mode 特徵)模型未產生任何特徵重要性。")
    else: print("\n(包含 mode 特徵)模型訓練未產生任何特徵重要性字典。")


    print("\n--- 正在測試集上產生預測 (使用包含 mode 特徵的模型) ---")
    submission_df = test_info_df_orig[['unique_id']].copy()
    for target_name_pred, final_model_pred in final_models_to_use.items():
        if final_model_pred is None:
            # ... (預設值填充) ...
            if target_name_pred == TARGET_COLUMNS["gender"]: submission_df[OUTPUT_COL_GENDER] = 0.5
            elif target_name_pred == TARGET_COLUMNS["hold racket handed"]: submission_df[OUTPUT_COL_HANDED] = 0.5
            elif target_name_pred == TARGET_COLUMNS["play years"]:
                for c in PLAY_YEARS_CLASSES_REF: submission_df[f"{OUTPUT_COL_YEARS_PREFIX}{c}"] = 1/len(PLAY_YEARS_CLASSES_REF)
            elif target_name_pred == TARGET_COLUMNS["level"]:
                for c in LEVEL_CLASSES_REF: submission_df[f"{OUTPUT_COL_LEVEL_PREFIX}{c}"] = 1/len(LEVEL_CLASSES_REF)
            continue
        
        # 確保 X_test_prepared 有模型期望的欄位
        if not X_test_prepared.empty and hasattr(final_model_pred, 'feature_names_in_'):
            # 對齊 X_test_prepared 的欄位到模型期望的 feature_names_in_
            # 如果 X_test_prepared 中缺少某些欄位，reindex 會用 fill_value (預設NaN) 填充，我們需要後續處理
            current_X_test_pred_aligned = X_test_prepared.reindex(columns=final_model_pred.feature_names_in_, fill_value=0.0)

            if all(f in current_X_test_pred_aligned.columns for f in final_model_pred.feature_names_in_):
                pred_features_for_submit = current_X_test_pred_aligned[final_model_pred.feature_names_in_]
                # ... (預測機率的邏輯不變) ...
                if target_name_pred == TARGET_COLUMNS["gender"]:
                    proba = final_model_pred.predict_proba(pred_features_for_submit)[:, final_model_pred.classes_.tolist().index(1)]
                    submission_df[OUTPUT_COL_GENDER] = proba
                elif target_name_pred == TARGET_COLUMNS["hold racket handed"]:
                    proba = final_model_pred.predict_proba(pred_features_for_submit)[:, final_model_pred.classes_.tolist().index(1)]
                    submission_df[OUTPUT_COL_HANDED] = proba
                elif target_name_pred == TARGET_COLUMNS["play years"]:
                    proba_matrix = final_model_pred.predict_proba(pred_features_for_submit)
                    for i, class_label in enumerate(final_model_pred.classes_):
                        if class_label in PLAY_YEARS_CLASSES_REF: submission_df[f"{OUTPUT_COL_YEARS_PREFIX}{class_label}"] = proba_matrix[:, i]
                elif target_name_pred == TARGET_COLUMNS["level"]:
                    proba_matrix = final_model_pred.predict_proba(pred_features_for_submit)
                    for i, class_label in enumerate(final_model_pred.classes_):
                        if class_label in LEVEL_CLASSES_REF: submission_df[f"{OUTPUT_COL_LEVEL_PREFIX}{class_label}"] = proba_matrix[:, i]
            else: print(f"警告：目標 {target_name_pred} 的測試特徵與模型期望不完全匹配(reindex後)，使用預設值。")
        else: print(f"警告：目標 {target_name_pred} 的 X_test_prepared 為空或模型無 feature_names_in_，使用預設值。")

    required_submission_cols = ["unique_id", OUTPUT_COL_GENDER, OUTPUT_COL_HANDED] + \
                               [f"{OUTPUT_COL_YEARS_PREFIX}{c}" for c in PLAY_YEARS_CLASSES_REF] + \
                               [f"{OUTPUT_COL_LEVEL_PREFIX}{c}" for c in LEVEL_CLASSES_REF]
    submission_df = pd.merge(test_info_df_orig[['unique_id']], submission_df, on='unique_id', how='left')
    for col_req in required_submission_cols:
        if col_req not in submission_df.columns:
            default_val = 0.5 if col_req in [OUTPUT_COL_GENDER, OUTPUT_COL_HANDED] else \
                          (1/len(PLAY_YEARS_CLASSES_REF) if OUTPUT_COL_YEARS_PREFIX in col_req else \
                          (1/len(LEVEL_CLASSES_REF) if OUTPUT_COL_LEVEL_PREFIX in col_req else ""))
            if col_req != 'unique_id': submission_df[col_req] = default_val
    submission_df = submission_df.fillna(0.0)
    submission_df[required_submission_cols].to_csv(f"submission_with_mode_model_{run_timestamp}.csv", index=False, float_format='%.8f')
    print(f"\n提交檔案 (包含 mode 特徵的模型) 已儲存至 submission_with_mode_model_{run_timestamp}.csv")

    # --- 評估並儲存訓練集預測與分數 ---
    print("\n--- 正在評估並儲存訓練集預測與分數 (標準 ROC AUC 評分, 使用包含 mode 特徵的模型) ---")
    # ... (此部分的評估邏輯與前一版標準 ROC AUC 評分相似) ...
    # ... 確保使用 final_models_to_use 和 X_train_full_prepared (它現在包含獨熱編碼後的 mode) ...
    train_set_eval_df = pd.DataFrame()
    source_for_eval_init = None
    # ... (與前一版相同的 train_set_eval_df 初始化和 actual_* 欄位添加邏輯) ...
    if 'train_df_outl' in locals() and isinstance(train_df_outl, pd.DataFrame) and not train_df_outl.empty and 'unique_id' in train_df_outl.columns:
        source_for_eval_init = train_df_outl
    elif 'train_info_df_orig' in locals() and isinstance(train_info_df_orig, pd.DataFrame) and not train_info_df_orig.empty and 'unique_id' in train_info_df_orig.columns:
        print("警告：'train_df_outl' 無法使用。將從 train_info_df_orig 初始化評估 DataFrame。")
        source_for_eval_init = train_info_df_orig
    if source_for_eval_init is not None:
        train_set_eval_df = source_for_eval_init[['unique_id']].copy()
        original_target_cols_for_report = {
            "gender": "actual_gender", "hold racket handed": "actual_hold_racket_handed",
            "play years": "actual_play_years", "level": "actual_level"
        }
        for csv_col_name, report_col_name in original_target_cols_for_report.items():
            if csv_col_name in source_for_eval_init.columns:
                actual_data_to_add = source_for_eval_init[['unique_id', csv_col_name]].rename(columns={csv_col_name: report_col_name})
                if report_col_name not in train_set_eval_df.columns:
                     train_set_eval_df = pd.merge(train_set_eval_df, actual_data_to_add, on='unique_id', how='left')
                else:
                     train_set_eval_df = train_set_eval_df.drop(columns=[report_col_name], errors='ignore').merge(actual_data_to_add, on='unique_id', how='left')
            elif report_col_name not in train_set_eval_df.columns :
                 train_set_eval_df[report_col_name] = np.nan
    else: print("嚴重錯誤：無法初始化 train_set_eval_df。")

    standard_roc_auc_scores = {}

    if not X_train_full_prepared.empty and ('train_df_outl' in locals() and isinstance(train_df_outl, pd.DataFrame)):
        for target_name_eval, model_eval in final_models_to_use.items():
            if model_eval is None or target_name_eval not in TARGET_COLUMNS.values():
                # ... (預設分數填充) ...
                if target_name_eval == TARGET_COLUMNS["gender"]: standard_roc_auc_scores['gender'] = 0.0
                elif target_name_eval == TARGET_COLUMNS["hold racket handed"]: standard_roc_auc_scores['hold_racket_handed'] = 0.0
                elif target_name_eval == TARGET_COLUMNS["play years"]: standard_roc_auc_scores['play_years'] = 0.0
                elif target_name_eval == TARGET_COLUMNS["level"]: standard_roc_auc_scores['level'] = 0.0
                continue
            if not hasattr(model_eval, 'feature_names_in_'):
                 print(f"警告: 模型 {target_name_eval} 沒有 feature_names_in_。跳過評估。")
                 continue
            
            # X_train_full_prepared 已經是預處理好的（包含獨熱編碼的 mode）
            # 確保使用的欄位與模型訓練時一致
            cols_for_eval_train = [f for f in model_eval.feature_names_in_ if f in X_train_full_prepared.columns]
            if len(cols_for_eval_train) != len(model_eval.feature_names_in_):
                print(f"警告: 目標 {target_name_eval} 訓練集評估時，X_train 特徵與模型期望不完全匹配。")
                # 嘗試用0填充缺失的期望欄位
                temp_X_eval_align_train = X_train_full_prepared.copy()
                for fn_in_eval_train in model_eval.feature_names_in_:
                    if fn_in_eval_train not in temp_X_eval_align_train.columns:
                         temp_X_eval_align_train[fn_in_eval_train] = 0.0
                X_train_for_this_target_eval = temp_X_eval_align_train[model_eval.feature_names_in_]
            else:
                X_train_for_this_target_eval = X_train_full_prepared[model_eval.feature_names_in_]


            if not X_train_for_this_target_eval.empty and target_name_eval in train_df_outl.columns:
                y_true_processed_eval = train_df_outl[target_name_eval].dropna()
                if not y_true_processed_eval.empty :
                    # 對齊 X 和 y 的索引
                    common_eval_index = X_train_for_this_target_eval.index.intersection(y_true_processed_eval.index)
                    X_aligned_eval_final = X_train_for_this_target_eval.loc[common_eval_index].dropna(axis=0, how='any')
                    y_true_eval_aligned_final = y_true_processed_eval.loc[X_aligned_eval_final.index]

                    if not X_aligned_eval_final.empty and not y_true_eval_aligned_final.empty:
                        pred_proba_eval_final = model_eval.predict_proba(X_aligned_eval_final)
                        if target_name_eval == TARGET_COLUMNS["gender"]:
                            proba_positive = pred_proba_eval_final[:, model_eval.classes_.tolist().index(1)]
                            train_set_eval_df.loc[y_true_eval_aligned_final.index, 'predicted_P_male'] = proba_positive
                            score = roc_auc_score(y_true_eval_aligned_final, proba_positive)
                            standard_roc_auc_scores['gender'] = score
                            print(f"  訓練集 性別 (標準 ROC AUC): {score:.4f}")
                        # ... (其他目標的標準 ROC AUC 計分邏輯) ...
                        elif target_name_eval == TARGET_COLUMNS["hold racket handed"]:
                            proba_positive = pred_proba_eval_final[:, model_eval.classes_.tolist().index(1)]
                            train_set_eval_df.loc[y_true_eval_aligned_final.index, 'predicted_P_right_handed'] = proba_positive
                            score = roc_auc_score(y_true_eval_aligned_final, proba_positive)
                            standard_roc_auc_scores['hold_racket_handed'] = score
                            print(f"  訓練集 持拍手 (標準 ROC AUC): {score:.4f}")
                        elif target_name_eval == TARGET_COLUMNS["play years"]:
                            y_true_filtered_eval_final = y_true_eval_aligned_final[y_true_eval_aligned_final.isin(model_eval.classes_)]
                            if not y_true_filtered_eval_final.empty:
                                pred_proba_aligned_eval_final = pd.DataFrame(pred_proba_eval_final, index=X_aligned_eval_final.index, columns=model_eval.classes_).loc[y_true_filtered_eval_final.index]
                                for i, class_label in enumerate(model_eval.classes_):
                                    if class_label in PLAY_YEARS_CLASSES_REF:
                                        train_set_eval_df.loc[y_true_filtered_eval_final.index, f'predicted_play_years_{class_label}'] = pred_proba_aligned_eval_final.iloc[:, i]
                                score = roc_auc_score(y_true_filtered_eval_final, pred_proba_aligned_eval_final, multi_class='ovr', average='micro', labels=model_eval.classes_)
                                standard_roc_auc_scores['play_years'] = score
                                print(f"  訓練集 球齡 Micro ROC AUC: {score:.4f}")
                        elif target_name_eval == TARGET_COLUMNS["level"]:
                            y_true_filtered_eval_final = y_true_eval_aligned_final[y_true_eval_aligned_final.isin(model_eval.classes_)]
                            if not y_true_filtered_eval_final.empty:
                                pred_proba_aligned_eval_final = pd.DataFrame(pred_proba_eval_final, index=X_aligned_eval_final.index, columns=model_eval.classes_).loc[y_true_filtered_eval_final.index]
                                for i, class_label in enumerate(model_eval.classes_):
                                    if class_label in LEVEL_CLASSES_REF:
                                        train_set_eval_df.loc[y_true_filtered_eval_final.index, f'predicted_level_{class_label}'] = pred_proba_aligned_eval_final.iloc[:, i]
                                score = roc_auc_score(y_true_filtered_eval_final, pred_proba_aligned_eval_final, multi_class='ovr', average='micro', labels=model_eval.classes_)
                                standard_roc_auc_scores['level'] = score
                                print(f"  訓練集 等級 Micro ROC AUC: {score:.4f}")
            # ... (確保所有目標都有分數的邏輯) ...
            for key_target_orig, key_target_proc in TARGET_COLUMNS.items():
                score_key_map = {TARGET_COLUMNS["gender"]: 'gender', TARGET_COLUMNS["hold racket handed"]: 'hold_racket_handed', TARGET_COLUMNS["play years"]: 'play_years', TARGET_COLUMNS["level"]: 'level'}
                score_key = score_key_map.get(key_target_proc)
                if score_key and score_key not in standard_roc_auc_scores:
                    standard_roc_auc_scores[score_key] = 0.0

        if len(standard_roc_auc_scores) == 4 and all(score is not None and score >= 0.0 for score in standard_roc_auc_scores.values()):
            average_standard_roc_auc_score = np.mean(list(standard_roc_auc_scores.values()))
            print(f"\n  訓練集平均分數 (標準 ROC AUC, 包含 mode): {average_standard_roc_auc_score:.4f}")
        else: print(f"\n  無法計算完整的訓練集平均分數 (標準 ROC AUC, 包含 mode)。 個別分數: {standard_roc_auc_scores}")
        train_eval_filename = f"train_evaluation_with_mode_StdROC_scores_{run_timestamp}.csv"
        # ... (儲存 train_set_eval_df 的邏輯) ...
        expected_pred_cols_for_train_eval = ['predicted_P_male', 'predicted_P_right_handed'] + \
                                   [f'predicted_play_years_{c}' for c in PLAY_YEARS_CLASSES_REF] + \
                                   [f'predicted_level_{c}' for c in LEVEL_CLASSES_REF]
        for col_to_check in expected_pred_cols_for_train_eval:
            if col_to_check not in train_set_eval_df.columns: train_set_eval_df[col_to_check] = np.nan
        report_cols_actual_names = [val for val in original_target_cols_for_report.values()]
        report_cols_order_final = ['unique_id'] + \
                            [col for col in report_cols_actual_names if col in train_set_eval_df.columns] + \
                            [col for col in expected_pred_cols_for_train_eval if col in train_set_eval_df.columns]
        current_cols_in_order_set = set(report_cols_order_final)
        other_cols_final = [col for col in train_set_eval_df.columns if col not in current_cols_in_order_set]
        final_report_cols_order_to_save = report_cols_order_final + other_cols_final
        final_report_cols_order_existing_in_df = [col for col in final_report_cols_order_to_save if col in train_set_eval_df.columns]
        if 'unique_id' in train_set_eval_df.columns:
            train_set_eval_df = train_set_eval_df.dropna(subset=['unique_id'])
        if not train_set_eval_df.empty:
            train_set_eval_df['unique_id'] = train_set_eval_df['unique_id'].astype(str)
            train_set_eval_df.to_csv(train_eval_filename, columns=final_report_cols_order_existing_in_df, index=False, float_format='%.8f')
            print(f"  訓練集實際值、預測機率和標準 ROC AUC 分數 (包含 mode) 已記錄 (詳細預測儲存於 {train_eval_filename})")
        else: print(f"  訓練集評估 DataFrame (train_set_eval_df) 為空。未儲存 {train_eval_filename}。")
    else: print("  因 X_train_full_prepared (包含 mode) 為空或 train_df_outl 無法使用，跳過訓練集評估計分細節。")

    print("\n--- 腳本執行完畢 ---")


# In[ ]:




