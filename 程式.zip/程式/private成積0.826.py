#!/usr/bin/env python
# coding: utf-8

# In[2]:


# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import os
import datetime
from autogluon.tabular import TabularPredictor
import warnings
import traceback # 用於打印詳細錯誤追蹤
import time # 用於計時
# 增加導入 for FFT 和其他信號處理
from numpy.fft import fft
from scipy.stats import skew, kurtosis # For skewness and kurtosis calculation if needed directly
from scipy.signal import find_peaks # Potential use for peak features, though not implemented below


# 忽略一些來自 Autogluon 的未來警告，讓輸出更簡潔
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning) # Ignore potential RuntimeWarnings from stats on NaNs
# 可以選擇忽略這個 Fragmentation Warning，但更好的做法是修復它
# warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)


# --- 設定路徑 (保持不變) ---
try: BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError: BASE_DIR = os.getcwd()
DATA_BASE_DIR = os.path.join(BASE_DIR, "data/pingpong")
TRAIN_DIR = os.path.join(DATA_BASE_DIR, "train")
TEST_DIR = os.path.join(DATA_BASE_DIR, "test")
OUTPUT_DIR = os.path.join(DATA_BASE_DIR, "output")
# 模型目錄名稱
MODEL_DIR = os.path.join(DATA_BASE_DIR, "autogluon_models_separate_advfeat_mode_knn_only") # 修改模型儲存目錄，以示區分
TRAIN_INFO_PATH = os.path.join(TRAIN_DIR, "train_info.csv")
TEST_INFO_PATH = os.path.join(TEST_DIR, "test_info.csv")
os.makedirs(OUTPUT_DIR, exist_ok=True); os.makedirs(MODEL_DIR, exist_ok=True)
print(f"Project base: {BASE_DIR}"); print(f"Data base: {DATA_BASE_DIR}")
print(f"Train dir: {TRAIN_DIR}"); print(f"Test dir: {TEST_DIR}")
print(f"Output dir: {OUTPUT_DIR}"); print(f"Model dir: {MODEL_DIR}")

# --- Helper function for calculating basic statistics ---
def calculate_basic_stats(series, prefix, features_dict):
    """Calculates basic stats (mean, std, min, max, median, q25, q75, skew, kurt) for a pandas Series."""
    if series is None or series.empty or series.isnull().all():
        stats_names = ['mean', 'std', 'min', 'max', 'median', 'q25', 'q75', 'skew', 'kurt']
        for stat_name in stats_names:
            features_dict[f'{prefix}_{stat_name}'] = np.nan
        return

    try: features_dict[f'{prefix}_mean'] = series.mean()
    except Exception: features_dict[f'{prefix}_mean'] = np.nan
    try: features_dict[f'{prefix}_std'] = series.std(ddof=0) # Population std dev
    except Exception: features_dict[f'{prefix}_std'] = np.nan
    try: features_dict[f'{prefix}_min'] = series.min()
    except Exception: features_dict[f'{prefix}_min'] = np.nan
    try: features_dict[f'{prefix}_max'] = series.max()
    except Exception: features_dict[f'{prefix}_max'] = np.nan
    try: features_dict[f'{prefix}_median'] = series.median()
    except Exception: features_dict[f'{prefix}_median'] = np.nan
    try: features_dict[f'{prefix}_q25'] = series.quantile(0.25)
    except Exception: features_dict[f'{prefix}_q25'] = np.nan
    try: features_dict[f'{prefix}_q75'] = series.quantile(0.75)
    except Exception: features_dict[f'{prefix}_q75'] = np.nan
    try: features_dict[f'{prefix}_skew'] = series.skew()
    except Exception: features_dict[f'{prefix}_skew'] = np.nan
    try: features_dict[f'{prefix}_kurt'] = series.kurt()
    except Exception: features_dict[f'{prefix}_kurt'] = np.nan

# --- Helper function for calculating advanced time-domain stats ---
def calculate_time_domain_stats(series, prefix, features_dict):
    """Calculates advanced time-domain stats (RMS, Energy, ZCR, Crest Factor, Shape Factor, Impulse Factor)."""
    if series is None or series.empty or series.isnull().all() or len(series) < 2:
        stats_names = ['rms', 'energy', 'zcr', 'crest_factor', 'shape_factor', 'impulse_factor']
        for stat_name in stats_names:
            features_dict[f'{prefix}_{stat_name}'] = np.nan
        return

    try:
        # Ensure series is numpy array for efficient calculations
        series_np = series.values
        n = len(series_np)
        mean_val = np.mean(series_np)
        # Use a small epsilon to avoid division by zero if series is all zeros
        epsilon = 1e-9
        abs_mean = np.mean(np.abs(series_np)) + epsilon # Average Absolute Value

        # RMS (Root Mean Square)
        try: features_dict[f'{prefix}_rms'] = np.sqrt(np.mean(series_np**2))
        except Exception: features_dict[f'{prefix}_rms'] = np.nan

        # Energy (Sum of Squares - note: depends on signal length)
        try: features_dict[f'{prefix}_energy'] = np.sum(series_np**2) # This is sum of squares, often used as energy proxy
        except Exception: features_dict[f'{prefix}_energy'] = np.nan

        # Zero Crossing Rate (ZCR) - count mean crossings
        try:
            # Shifted series to cross the mean
            shifted_series = series_np - mean_val
            # Find where the sign changes (excluding the zero point itself if it exists)
            zero_crossings = np.where(np.diff(np.sign(shifted_series)))[0]
            features_dict[f'{prefix}_zcr'] = len(zero_crossings) / n if n > 0 else 0.0 # Normalized ZCR
        except Exception: features_dict[f'{prefix}_zcr'] = np.nan

        # Peak Value (Absolute Max)
        peak_val = np.max(np.abs(series_np))

        # RMS with epsilon for Crest Factor calculation
        rms_val = features_dict.get(f'{prefix}_rms', np.nan)
        rms_val_safe = rms_val if not pd.isna(rms_val) and rms_val != 0 else epsilon

        # Crest Factor (Peak / RMS)
        try: features_dict[f'{prefix}_crest_factor'] = peak_val / rms_val_safe
        except Exception: features_dict[f'{prefix}_crest_factor'] = np.nan
        # if np.isinf(features_dict[f'{prefix}_crest_factor']): features_dict[f'{prefix}_crest_factor'] = np.nan # Should be handled by epsilon

        # Shape Factor (RMS / Average Absolute Value)
        try: features_dict[f'{prefix}_shape_factor'] = rms_val_safe / abs_mean
        except Exception: features_dict[f'{prefix}_shape_factor'] = np.nan
        # if np.isinf(features_dict[f'{prefix}_shape_factor']): features_dict[f'{prefix}_shape_factor'] = np.nan

        # Impulse Factor (Peak / Average Absolute Value)
        try: features_dict[f'{prefix}_impulse_factor'] = peak_val / abs_mean
        except Exception: features_dict[f'{prefix}_impulse_factor'] = np.nan
        # if np.isinf(features_dict[f'{prefix}_impulse_factor']): features_dict[f'{prefix}_impulse_factor'] = np.nan

    except Exception as e:
        stats_names = ['rms', 'energy', 'zcr', 'crest_factor', 'shape_factor', 'impulse_factor']
        for stat_name in stats_names:
            features_dict[f'{prefix}_{stat_name}'] = np.nan


# --- Helper function for calculating advanced frequency-domain stats ---
def calculate_frequency_domain_stats(fft_mags_series, prefix, features_dict):
    """Calculates advanced frequency-domain stats (Spectral Centroid, Spread, Skew, Kurt) from FFT magnitudes."""
    if fft_mags_series is None or fft_mags_series.empty or fft_mags_series.isnull().all() or len(fft_mags_series) < 2:
        stats_names = ['spectral_centroid', 'spectral_spread', 'spectral_skew', 'spectral_kurt']
        for stat_name in stats_names:
            features_dict[f'{prefix}_{stat_name}'] = np.nan
        return

    try:
        # Ensure magnitudes are non-negative and handle potential issues
        mags_np = fft_mags_series.values.copy()
        mags_np[mags_np < 0] = 0 # Ensure non-negative magnitudes

        n_mags = len(mags_np)
        freq_bins = np.arange(1, n_mags + 1)

        epsilon = 1e-9
        total_magnitude = np.sum(mags_np)
        total_magnitude_safe = total_magnitude if total_magnitude != 0 else epsilon

        norm_mags = mags_np / total_magnitude_safe

        # Spectral Centroid (weighted mean frequency)
        try: features_dict[f'{prefix}_spectral_centroid'] = np.sum(freq_bins * norm_mags)
        except Exception: features_dict[f'{prefix}_spectral_centroid'] = np.nan

        # Spectral Spread (weighted standard deviation of frequency)
        try:
            centroid = features_dict.get(f'{prefix}_spectral_centroid', np.nan)
            if not np.isnan(centroid):
                squared_diff_sum = np.sum(((freq_bins - centroid)**2) * norm_mags)
                features_dict[f'{prefix}_spectral_spread'] = np.sqrt(squared_diff_sum) if squared_diff_sum >= 0 else np.nan
            else: features_dict[f'{prefix}_spectral_spread'] = np.nan
        except Exception: features_dict[f'{prefix}_spectral_spread'] = np.nan

        # Higher order moments: Spectral Skewness and Kurtosis (normalized)
        try:
            centroid = features_dict.get(f'{prefix}_spectral_centroid', np.nan)
            spread = features_dict.get(f'{prefix}_spectral_spread', np.nan)
            spread_safe = spread if not pd.isna(spread) and spread > 0 else epsilon

            if not np.isnan(centroid) and not np.isnan(spread_safe):
                m3 = np.sum(((freq_bins - centroid)**3) * norm_mags)
                m4 = np.sum(((freq_bins - centroid)**4) * norm_mags)
                features_dict[f'{prefix}_spectral_skew'] = m3 / (spread_safe**3)
                features_dict[f'{prefix}_spectral_kurt'] = m4 / (spread_safe**4) - 3 # Fisher's kurtosis
            else:
                features_dict[f'{prefix}_spectral_skew'] = np.nan
                features_dict[f'{prefix}_spectral_kurt'] = np.nan
        except Exception:
            features_dict[f'{prefix}_spectral_skew'] = np.nan
            features_dict[f'{prefix}_spectral_kurt'] = np.nan


    except Exception as e:
        stats_names = ['spectral_centroid', 'spectral_spread', 'spectral_skew', 'spectral_kurt']
        for stat_name in stats_names:
            features_dict[f'{prefix}_{stat_name}'] = np.nan


# --- 特徵工程函數 ---
def extract_features_from_txt(file_path):
    """
    從 txt 檔案讀取時序數據並提取多種特徵:
    1. 原始信號統計量 (基本 + 進階時域)
    2. 信號幅度統計量 (基本 + 進階時域)
    3. 差分信號統計量 (基本 + 進階時域)
    4. FFT 幅度統計量 (基本 + 進階頻域)
    """
    base_cols = ['Ax', 'Ay', 'Az', 'Gx', 'Gy', 'Gz']
    all_cols_to_process = base_cols

    features = {}

    try:
        data = pd.read_csv(file_path, sep=' ', header=None, on_bad_lines='skip', low_memory=False, dtype=float)
        if data.empty or data.shape[1] != 6:
            return features # Return empty dict if file is empty or has wrong shape

        data.columns = base_cols

        # Check and calculate magnitudes, add to list only if base data exists
        if not data[['Ax', 'Ay', 'Az']].isnull().all().all():
            data['Acc_Mag'] = np.sqrt(data['Ax']**2 + data['Ay']**2 + data['Az']**2)
            all_cols_to_process.append('Acc_Mag')
        else: data['Acc_Mag'] = np.nan

        if not data[['Gx', 'Gy', 'Gz']].isnull().all().all():
            data['Gyr_Mag'] = np.sqrt(data['Gx']**2 + data['Gy']**2 + data['Gz']**2)
            all_cols_to_process.append('Gyr_Mag')
        else: data['Gyr_Mag'] = np.nan


        for col in all_cols_to_process:
            series = data[col].dropna()

            if series.empty or len(series) < 2:
                calculate_basic_stats(None, col, features)
                calculate_time_domain_stats(None, col, features)
                calculate_basic_stats(None, f"{col}_diff", features)
                calculate_time_domain_stats(None, f"{col}_diff", features)
                calculate_basic_stats(None, f"{col}_fft_mag", features)
                calculate_frequency_domain_stats(None, f"{col}_fft_mag", features)
                continue

            # a) Basic stats for original/magnitude signal
            calculate_basic_stats(series, col, features)
            # a') Advanced time-domain stats for original/magnitude signal
            calculate_time_domain_stats(series, col, features)


            # b) Difference signal stats (basic + advanced time-domain)
            try:
                diff_series = series.diff().iloc[1:].dropna()
                if len(diff_series) >= 2:
                    calculate_basic_stats(diff_series, f"{col}_diff", features)
                    calculate_time_domain_stats(diff_series, f"{col}_diff", features)
                else:
                    calculate_basic_stats(None, f"{col}_diff", features)
                    calculate_time_domain_stats(None, f"{col}_diff", features)
            except Exception as e_diff:
                calculate_basic_stats(None, f"{col}_diff", features)
                calculate_time_domain_stats(None, f"{col}_diff", features)


            # c) FFT Magnitude stats (basic + advanced frequency-domain)
            try:
                fft_coeffs = fft(series.values)
                fft_mags = np.abs(fft_coeffs[1:len(fft_coeffs)//2])

                if len(fft_mags) >= 2:
                    fft_mags_series = pd.Series(fft_mags)
                    calculate_basic_stats(fft_mags_series, f"{col}_fft_mag", features)
                    calculate_frequency_domain_stats(fft_mags_series, f"{col}_fft_mag", features)
                else:
                    calculate_basic_stats(None, f"{col}_fft_mag", features)
                    calculate_frequency_domain_stats(None, f"{col}_fft_mag", features)

            except Exception as e_fft:
                calculate_basic_stats(None, f"{col}_fft_mag", features)
                calculate_frequency_domain_stats(None, f"{col}_fft_mag", features)

        return features

    except Exception as e:
        print(f"Major error processing file {file_path}: {e}")
        traceback.print_exc()
        return {}


# --- 動態生成所有可能的時序特徵名稱 ---
def get_all_timeseries_feature_names():
    """Generates a list of all feature names created by extract_features_from_txt."""
    base_cols = ['Ax', 'Ay', 'Az', 'Gx', 'Gy', 'Gz']
    mag_cols = ['Acc_Mag', 'Gyr_Mag']
    all_signal_cols = base_cols + mag_cols

    basic_stats_names = ['mean', 'std', 'min', 'max', 'median', 'q25', 'q75', 'skew', 'kurt']
    time_stats_names = ['rms', 'energy', 'zcr', 'crest_factor', 'shape_factor', 'impulse_factor']
    freq_stats_names = ['spectral_centroid', 'spectral_spread', 'spectral_skew', 'spectral_kurt']

    suffixes = {
        '': basic_stats_names + time_stats_names,
        '_diff': basic_stats_names + time_stats_names,
        '_fft_mag': basic_stats_names + basic_stats_names + freq_stats_names # Note: basic_stats_names appears twice for FFT magnitudes
    }

    feature_names = []
    for col in all_signal_cols:
        for suffix, stats in suffixes.items():
            for stat in stats:
                feature_names.append(f"{col}{suffix}_{stat}")

    feature_names = list(sorted(list(set(feature_names))))
    return feature_names

ALL_TIMESERIES_FEATURE_NAMES = get_all_timeseries_feature_names()
print(f"Total expected timeseries features per file: {len(ALL_TIMESERIES_FEATURE_NAMES)}")


# --- 資料處理函數 ---
def process_data(info_path, data_dir):
    print(f"\nProcessing data from: {info_path} and {data_dir}")
    if not os.path.exists(info_path): print(f"Error: Not found {info_path}"); return None
    if not os.path.exists(data_dir): print(f"Error: Not found {data_dir}"); return None
    try: info_df = pd.read_csv(info_path)
    except Exception as e: print(f"Error reading {info_path}: {e}"); return None
    if 'unique_id' not in info_df.columns: print(f"Error: 'unique_id' missing in {info_path}"); return None

    all_features_list = []
    total_ids = len(info_df['unique_id'])
    processed_count = 0; start_time = time.time()

    for unique_id in info_df['unique_id']:
        try: file_name = f"{int(unique_id)}.txt"
        except ValueError: file_name = f"{unique_id}.txt"
        txt_file_path = os.path.join(data_dir, file_name)

        if os.path.exists(txt_file_path):
            features = extract_features_from_txt(txt_file_path)
        else:
            features = {} # Empty dict if file not found

        # Ensure all expected timeseries columns exist, fill missing with NaN
        processed_features = {'original_unique_id': unique_id}
        for fn in ALL_TIMESERIES_FEATURE_NAMES:
            processed_features[fn] = features.get(fn, np.nan)

        all_features_list.append(processed_features)
        processed_count += 1
        if processed_count % 100 == 0 or processed_count == total_ids:
            elapsed = time.time() - start_time
            eta = (elapsed / processed_count * (total_ids - processed_count)) if processed_count > 0 else 0
            print(f"Processed {processed_count}/{total_ids} files... (ETA: {eta:.0f}s)", end='\r')

    print(f"\nFinished reading {processed_count} files in {time.time() - start_time:.2f}s.")
    if not all_features_list: print("Error: No timeseries features extracted."); return None

    timeseries_features_df = pd.DataFrame(all_features_list)

    try: # Align ID types for merging
        info_df['unique_id_aligned'] = pd.to_numeric(info_df['unique_id'], errors='coerce').fillna(info_df['unique_id']).astype(str)
        timeseries_features_df['unique_id_aligned'] = pd.to_numeric(timeseries_features_df['original_unique_id'], errors='coerce').fillna(timeseries_features_df['original_unique_id']).astype(str)

    except Exception as e:
        print(f"Warn: Aligning ID types failed, falling back to original unique_id as str: {e}")
        info_df['unique_id_aligned'] = info_df['unique_id'].astype(str)
        timeseries_features_df['unique_id_aligned'] = timeseries_features_df['original_unique_id'].astype(str)

    # Merge info_df (including unique_id, mode, targets) with timeseries_features_df
    merged_df = pd.merge(
        info_df.drop(columns=['unique_id'], errors='ignore'),
        timeseries_features_df.drop(columns=['original_unique_id'], errors='ignore'),
        on='unique_id_aligned',
        how='left'
    )
    merged_df = merged_df.rename(columns={'unique_id_aligned': 'unique_id'}) # Rename back


    print(f"Finished processing. Shape: {merged_df.shape}")

    # Check for NaNs in timeseries features after merging
    ts_feature_cols_in_merged = [col for col in ALL_TIMESERIES_FEATURE_NAMES if col in merged_df.columns]

    if merged_df[ts_feature_cols_in_merged].isnull().any().any():
        nan_counts = merged_df[ts_feature_cols_in_merged].isnull().sum()
        nan_cols_with_counts = nan_counts[nan_counts > 0]
        if not nan_cols_with_counts.empty:
            print("\nWarning: NaNs found in the following timeseries feature columns after merging:")
            print(nan_cols_with_counts)
            all_nan_cols = nan_cols_with_counts[nan_counts_with_counts == len(merged_df)].index.tolist()
            if all_nan_cols:
                print(f"\nWarning: The following timeseries feature columns are *entirely* NaN: {all_nan_cols}")

    return merged_df


# --- 1. 載入訓練資料 ---
print("="*30); print("Step 1: Load Train Data"); print("="*30)
train_data = process_data(TRAIN_INFO_PATH, TRAIN_DIR)
if train_data is None: exit("Failed to load training data.")

targets_config = {'gender': 'binary', 'hold racket handed': 'binary', 'play years': 'multiclass', 'level': 'multiclass'}
target_labels = list(targets_config.keys())
id_cols = ['unique_id', 'player_id', 'cut_point'] # Columns to exclude as features

# Check for missing targets and handle non-numeric targets
missing_targets = [l for l in target_labels if l not in train_data.columns]
if missing_targets:
    print(f"Error: Missing target columns in train_data: {missing_targets}"); exit("Missing target columns.")

for l in target_labels:
    train_data[l] = pd.to_numeric(train_data[l], errors='coerce')
    if train_data[l].isnull().any():
        print(f"Warning: NaN values found in target '{l}'. Dropping rows with NaN target.")
        initial_rows = len(train_data)
        train_data.dropna(subset=[l], inplace=True)
        if len(train_data) < initial_rows:
            print(f"Dropped {initial_rows - len(train_data)} rows with NaN in target '{l}'.")

    if pd.api.types.is_float_dtype(train_data[l]):
        if (train_data[l] == train_data[l].round()).all():
            print(f"Converting float target '{l}' to integer.")
            train_data[l] = train_data[l].astype(int)


# Define the actual feature columns for AutoGluon training
# This includes 'mode' and all the generated timeseries features that are present in the dataframe
ag_feature_cols = ['mode'] + [col for col in ALL_TIMESERIES_FEATURE_NAMES if col in train_data.columns]

# Create the base training data for AutoGluon - include unique_id for reference, features, and targets
# Exclude other info columns like player_id, cut_point
train_data_base = train_data[['unique_id'] + ag_feature_cols + target_labels].copy()

print(f"Train data base shape: {train_data_base.shape}")
print(f"AutoGluon will use {len(ag_feature_cols)} feature columns: {ag_feature_cols}")


# --- 2. 載入測試資料 ---
print("\n" + "="*30); print("Step 2: Load Test Data"); print("="*30)
test_data = process_data(TEST_INFO_PATH, TEST_DIR)
if test_data is None: exit("Failed to load test data.")

# Keep test_ids separately
test_ids = test_data[['unique_id']].copy()

# Prepare test features for prediction, aligning with the defined ag_feature_cols
# --- FIX: Address Fragmentation Warning ---
# Instead of building test_features_for_prediction piece by piece,
# create it with all necessary columns upfront and then fill data.

print(f"\nAligning test features with {len(ag_feature_cols)} training feature columns (including 'mode')...")

# 1. Create the prediction DataFrame with all required AG feature columns, initialized with NaN
test_features_for_prediction = pd.DataFrame(index=test_data.index, columns=ag_feature_cols)

# 2. Copy the actual data from test_data for the columns that exist in test_data
cols_in_test_and_ag = [col for col in ag_feature_cols if col in test_data.columns]
test_features_for_prediction[cols_in_test_and_ag] = test_data[cols_in_test_and_ag]

# Columns in ag_feature_cols but NOT in test_data.columns will remain NaN in test_features_for_prediction, which is correct.
missing_in_test_source = [col for col in ag_feature_cols if col not in cols_in_test_and_ag]
if missing_in_test_source:
    print(f"Warning: The following AG feature columns were not found in the original test_data and remain NaN: {missing_in_test_source}")


# 3. Impute NaNs in *numerical* test features using training medians
# AutoGluon handles categorical NaNs ('mode') well internally, so only impute numerical ones.
numerical_ag_feature_cols = [col for col in ag_feature_cols if col != 'mode']
imputation_values = {}

print("Imputing NaNs in numerical test features using training medians...")
for col in numerical_ag_feature_cols:
    if test_features_for_prediction[col].isnull().any():
        train_median = train_data_base[col].median()
        if pd.isna(train_median):
            train_median = train_data_base[col].mean()
            if pd.isna(train_median):
                train_median = 0
                # print(f"Warn: Training median and mean for '{col}' are NaN. Using 0 for imputation.")

        imputation_values[col] = train_median
        test_features_for_prediction[col].fillna(train_median, inplace=True)

# Double check if any NaNs remain in test features after imputation (including 'mode')
if test_features_for_prediction[ag_feature_cols].isnull().any().any():
    print("\nWarning: NaNs still remain in test features after imputation!")
    nan_counts_test_ag = test_features_for_prediction[ag_feature_cols].isnull().sum()
    print(nan_counts_test_ag[nan_counts_test_ag > 0])
else:
    print("NaN imputation in test features completed successfully.")

# --- End of Fragmentation Warning Fix ---


print(f"Train data base shape (for AG fit): {train_data_base.shape}")
print(f"Test features shape (for AG predict): {test_features_for_prediction.shape}")
# Check 'mode' dtype in the final prediction DataFramebest
if 'mode' in test_features_for_prediction.columns:
    print(f"Test features 'mode' column dtype: {test_features_for_prediction['mode'].dtype}. AutoGluon should handle this as categorical.")


# --- 3. 訓練模型 (使用 'best_quality' 和 time_limit) ---
print("\n" + "="*30); print("Step 3: Training Separate Models"); print("="*30)
predictors = {}; fit_start_time = time.time()
for label, problem_type in targets_config.items():
    print(f"\n--- Training for: '{label}' ({problem_type}) ---")
    predictor_path = os.path.join(MODEL_DIR, f"predictor_{label.replace(' ', '_')}")
    eval_metric = 'roc_auc' if problem_type == 'binary' else 'roc_auc_ovr_weighted'
    print(f"Eval_metric: {eval_metric}")

    current_train_cols_for_fit = [label] + ag_feature_cols
    train_data_for_fit = train_data_base[current_train_cols_for_fit].copy()

    initial_rows = len(train_data_for_fit)
    train_data_for_fit.dropna(subset=[label], inplace=True)
    if len(train_data_for_fit) < initial_rows:
        print(f"Warning: Dropped {initial_rows - len(train_data_for_fit)} rows with NaN in target '{label}' before fitting.")

    constant_cols = [col for col in ag_feature_cols if train_data_for_fit[col].nunique(dropna=False) <= 1]
    if constant_cols:
        print(f"Warning: Constant or single-value feature columns found for target '{label}': {constant_cols}. These might be dropped or cause issues for some AutoGluon models.")

    try:
        predictor = TabularPredictor(label=label, eval_metric=eval_metric, path=predictor_path, verbosity=2)

        print(f"Starting fit for '{label}' (Data shape: {train_data_for_fit.shape})...")
        fit_single_start = time.time()
        predictor.fit(
            train_data_for_fit, # Pass the dataframe containing features AND label
            # presets='high_quality', # 移除 presets，改用 hyperparameters
            hyperparameters={'KNN': {}}, # **此處是關鍵修改**：只訓練 KNN 模型
            time_limit=3600
        )
        print(f"Fit finished for '{label}' in {time.time() - fit_single_start:.2f}s.")
        predictors[label] = predictor
    except Exception as e:
        print(f"CRITICAL ERROR fitting '{label}': {e}")
        traceback.print_exc()
        predictors[label] = None

print(f"\nFinished training all models in {time.time() - fit_start_time:.2f}s.")

# --- 3.6 提取洞察 ---
print("\n" + "="*30); print("Step 3.6: Extracting Model Insights"); print("="*30)
all_leaderboards = []; all_feature_importance = []
insight_start_time = time.time()
timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

successful_predictors = {label: p for label, p in predictors.items() if p is not None}

if not successful_predictors:
    print("No models trained successfully. Skipping insights.")
else:
    print(f"Extracting insights for: {list(successful_predictors.keys())}")
    for label, predictor in successful_predictors.items():
        print(f"\n--- Insights for: '{label}' ---")
        current_train_cols_for_eval = [label] + ag_feature_cols
        train_data_for_eval = train_data_base[current_train_cols_for_eval].copy().dropna(subset=[label])

        try: # Leaderboard
            print(f"Getting leaderboard for '{label}'...")
            lb = predictor.leaderboard(train_data_for_eval, silent=True) # Leaderboard also needs features + label
            lb['target'] = label; all_leaderboards.append(lb)
            print(f"Leaderboard extracted. Best score: {lb['score_val'].iloc[0]:.4f}")
        except Exception as e: print(f"Could not get leaderboard for '{label}': {e}")

        try: # Feature Importance - THIS SECTION SAVES TO CSV
            print(f"Calculating feature importance for '{label}'...")
            fi_start = time.time()
            # --- FIX: Pass the dataframe WITH the label column ---
            # The feature_importance method expects the full dataframe used for training/evaluation
            fi = predictor.feature_importance(train_data_for_eval, num_shuffle_sets=3)
            # --- END FIX ---
            fi = fi.reset_index().rename(columns={'index': 'feature'})
            fi['target'] = label; all_feature_importance.append(fi)
            print(f"Importance calculated for '{label}' in {time.time()-fi_start:.2f}s.")
        except Exception as e:
            print(f"Could not get feature importance for '{label}': {e}")
            traceback.print_exc()

    if all_leaderboards: # Save Leaderboard
        try:
            lb_df = pd.concat(all_leaderboards, ignore_index=True)
            lb_cols = ['target', 'model', 'score_val', 'eval_metric', 'pred_time_val', 'fit_time', 'stack_level']
            lb_df = lb_df[[c for c in lb_cols if c in lb_df.columns]]
            lb_file = os.path.join(OUTPUT_DIR, f"model_scores_{timestamp}.csv")
            lb_df.to_csv(lb_file, index=False, float_format='%.6f')
            print(f"\nModel scores saved: {lb_file}")
        except Exception as e: print(f"Error saving leaderboard: {e}")

    # --- FEATURE IMPORTANCE SAVE LOGIC (Already existed) ---
    if all_feature_importance: # Save Feature Importance
        try:
            fi_df = pd.concat(all_feature_importance, ignore_index=True)
            fi_cols = ['target', 'feature', 'importance', 'stddev', 'p_value', 'n']
            fi_df = fi_df[[c for c in fi_cols if c in fi_df.columns]]
            fi_df = fi_df.sort_values(by=['target','importance'], ascending=[True,False])
            fi_file = os.path.join(OUTPUT_DIR, f"feature_importance_{timestamp}.csv")
            fi_df.to_csv(fi_file, index=False, float_format='%.6f')
            print(f"Feature importance saved: {fi_file}")
        except Exception as e: print(f"Error saving feature importance: {e}")
    # --- END FEATURE IMPORTANCE SAVE LOGIC ---

    print(f"\nFinished extracting insights in {time.time() - insight_start_time:.2f}s.")

# --- 4. 預測 ---
print("\n" + "="*30); print("Step 4: Making Predictions"); print("="*30)
all_predictions = {}; predict_start_time = time.time()

successful_predictors = {label: p for label, p in predictors.items() if p is not None}

if not successful_predictors:
    print("No models trained successfully. Skipping prediction.")
else:
    print(f"Predicting using test data for targets: {list(successful_predictors.keys())}")
    # Select only the feature columns defined for AG training from the prepared test features
    # test_features_for_prediction already contains all necessary AG features and is aligned/imputed
    test_features_for_ag_predict = test_features_for_prediction[ag_feature_cols]

    for label, predictor in successful_predictors.items():
        try:
            print(f"Predicting probabilities for '{label}'...")
            all_predictions[label] = predictor.predict_proba(test_features_for_ag_predict, as_multiclass=True)
            print(f"Prediction done for '{label}'. Shape: {all_predictions[label].shape}")
        except Exception as e:
            print(f"Error predicting for '{label}': {e}")
            traceback.print_exc()


print(f"Finished prediction in {time.time() - predict_start_time:.2f}s.")


# --- 5. 格式化輸出 ---
print("\n" + "="*30); print("Step 5: Formatting Output CSV"); print("="*30)
output_start_time = time.time()

if not all_predictions:
    print("Skipping output: No successful predictions.")
else:
    try:
        submission_df = test_ids.copy()

        default_probs = {
            'gender': {0: 0.5, 1: 0.5},
            'hold racket handed': {0: 0.5, 1: 0.5},
            'play years': {0: 1/3, 1: 1/3, 2: 1/3},
            'level': {2: 0.25, 3: 0.25, 4: 0.25, 5: 0.25}
        }

        required_cols = ["unique_id", "gender", "hold racket handed", "play years_0", "play years_1", "play years_2", "level_2", "level_3", "level_4", "level_5"]

        for label in target_labels:
            if label in all_predictions and all_predictions[label] is not None:
                pred_proba_df = all_predictions[label]

                if label in ['gender', 'hold racket handed']:
                    submission_df[label] = pred_proba_df.get(1, default_probs[label][1])

                elif label == 'play years':
                    submission_df['play years_0'] = pred_proba_df.get(0, default_probs[label][0])
                    submission_df['play years_1'] = pred_proba_df.get(1, default_probs[label][1])
                    submission_df['play years_2'] = pred_proba_df.get(2, default_probs[label][2])

                elif label == 'level':
                    submission_df['level_2'] = pred_proba_df.get(2, default_probs[label][2])
                    submission_df['level_3'] = pred_proba_df.get(3, default_probs[label][3])
                    submission_df['level_4'] = pred_proba_df.get(4, default_probs[label][4])
                    submission_df['level_5'] = pred_proba_df.get(5, default_probs[label][5])
            else:
                print(f"Warning: Prediction missing or failed for '{label}'. Filling with default probabilities.")
                if label in ['gender', 'hold racket handed']:
                    submission_df[label] = default_probs[label][1]
                elif label == 'play years':
                    submission_df['play years_0'] = default_probs[label][0]
                    submission_df['play years_1'] = default_probs[label][1]
                    submission_df['play years_2'] = default_probs[label][2]
                elif label == 'level':
                    submission_df['level_2'] = default_probs[label][2]
                    submission_df['level_3'] = default_probs[label][3]
                    submission_df['level_4'] = default_probs[label][4]
                    submission_df['level_5'] = default_probs[label][5]


        for col in required_cols:
            if col not in submission_df.columns:
                print(f"Warning: Required submission column '{col}' not found. Adding with default value 0.5.")
                submission_df[col] = 0.5


        submission_cols_to_check = [c for c in required_cols if c != 'unique_id']
        if submission_df[submission_cols_to_check].isnull().any().any():
            print("\nWarning: NaNs found in final submission probability columns!")
            for col in submission_cols_to_check:
                if submission_df[col].isnull().any():
                    col_mean = submission_df[col].mean()
                    fill_value = col_mean if not pd.isna(col_mean) else 0.5
                    submission_df[col].fillna(fill_value, inplace=True)
                    print(f"Filled NaNs in '{col}' with {fill_value:.4f}.")


        submission_df = submission_df[required_cols]

        output_filename = os.path.join(OUTPUT_DIR, f"submission_{timestamp}.csv")
        submission_df.to_csv(output_filename, index=False, float_format='%.4f')

        print(f"\nSubmission file created: {output_filename}")
        print("Final submission preview:")
        with pd.option_context('display.max_rows', None, 'display.max_columns', None, 'display.float_format', '{:.4f}'.format):
            print(submission_df.head())

    except Exception as e:
        print(f"\nError formatting output: {e}")
        traceback.print_exc()

print(f"\nFinished output generation in {time.time() - output_start_time:.2f}s.")
print("\nScript finished.")


# In[ ]:




